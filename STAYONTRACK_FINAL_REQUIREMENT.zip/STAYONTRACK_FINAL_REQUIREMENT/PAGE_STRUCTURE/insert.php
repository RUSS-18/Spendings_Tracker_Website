<?php

include('config.php');

$filePath ='C:\xampp\htdocs\stayontrack\STAYONTRACK_FINAL_REQUIREMENT\PAGE_STRUCTURE\henlo.txt';
// Check if the file exists
if (file_exists($filePath)) {
  // Read the contents of the file
  $contents = file_get_contents($filePath);

  // Output the contents
  $fileLines = file($filePath, FILE_IGNORE_NEW_LINES);

// Echo each line of the file
$arr =[];
$arr2=[];
$x =0;
foreach ($fileLines as $line) {
    $arr[$x] = $line;
    $x++;
}
} else {
  echo "File not found.";
}

for($a=0;$a<$x;$a++){
    echo $arr[$a]."<br>";
    $arr2 = explode('~',$arr[$a]);
    
    $arr2[4] = str_replace(',','',$arr2[4]);
  //do the adding in php here
  $Cat_Id ="";
  $User_Id="";
  $Sub_Id="";
  
if($arr2[1] =="Expenses"){
  $Cat_Id=1;
}else{
  $Cat_Id=2;
}
if ($arr2[1] == "Expenses") {
  $sql = "SELECT `Sub-category_Id` FROM tbl_subcatexpenses WHERE `Sub-category_name` = '$arr2[2]'";
  $result = $conn->query($sql);
  while ($row = $result->fetch(PDO::FETCH_ASSOC)) {

    $Sub_Id = $row['Sub-category_Id'];
  }
} else {
  $sql = "SELECT `Sub-Category_Id` FROM tbl_subcatincomes WHERE `Sub-category_name` = '$arr2[2]'";
  $result = $conn->query($sql);
  while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
    $Sub_Id = $row['Sub-Category_Id'];
  }
}



              $sql = "SELECT * FROM tbl_tracking";
              $result=$conn->query($sql);
              while($row=$result->fetch(PDO::FETCH_ASSOC)){
              $User_Id = $row['User_Id'];
              }

                //setting up image
              
                $sql = "INSERT INTO tbl_spendings (Category_Id, `Sub-Category_Id`, User_Id, Item_name, Cost, Date) 
        VALUES (:cat, :sub, :user, :item, :cost, :date)";
$stmt = $conn->prepare($sql);
$stmt->execute([
    ':cat' => $Cat_Id,
    ':sub' => $Sub_Id,
    ':user' => $User_Id,
    ':item' => $arr2[0],
    ':cost' => $arr2[3],
    ':date' => $arr2[4],
]);
              }



          

$filePath = 'C:\xampp\htdocs\stayontrack\STAYONTRACK_FINAL_REQUIREMENT\PAGE_STRUCTURE\henlo.txt';
file_put_contents($filePath, '');
?>


