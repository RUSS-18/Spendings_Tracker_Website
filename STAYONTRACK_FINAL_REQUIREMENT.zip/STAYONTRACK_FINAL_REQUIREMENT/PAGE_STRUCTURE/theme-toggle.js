function toggleTheme() {
  var link = document.getElementById("theme-link");
  var button = document.getElementById("theme-toggle-button");
  var icon = document.getElementById("theme-toggle-icon");

  if (link.getAttribute("href") === "default-theme.css") {
    applyDarkTheme();
  } else {
    applyDefaultTheme();
  }
}

function applyDefaultTheme() {
  var link = document.getElementById("theme-link");
  var button = document.getElementById("theme-toggle-button");
  var icon = document.getElementById("theme-toggle-icon");

  link.href = "default-theme.css";
  icon.className = "fas fa-sun";
  button.classList.remove("dark");

  // Store the selected theme in local storage
  localStorage.setItem('theme', 'default');
}

function applyDarkTheme() {
  var link = document.getElementById("theme-link");
  var button = document.getElementById("theme-toggle-button");
  var icon = document.getElementById("theme-toggle-icon");

  link.href = "dark-theme.css";
  icon.className = "fas fa-moon";
  button.classList.add("dark");

  // Store the selected theme in local storage
  localStorage.setItem('theme', 'dark');
}
