<?php
// Get the text data from the AJAX request
$item= $_POST['item'];
$category = $_POST['category'];
$subCategory = $_POST['subCategory'];
$amount = $_POST['amount'];
$date = $_POST['date'];

$concat = $item.'~'.$category.'~'.$subCategory.'~'.$amount.'~'.$date;
// File path to save the text data
$filePath = 'C:\xampp\htdocs\stayontrack\STAYONTRACK_FINAL_REQUIREMENT\PAGE_STRUCTURE\henlo.txt';

// Save the text data to the file

if($concat != ''){;
file_put_contents($filePath,$concat . PHP_EOL, FILE_APPEND);
}else if($concat == ''){
    file_put_contents($filePath, '');
}
// Send a response back to the client
echo "Text data saved successfully.";
?>
