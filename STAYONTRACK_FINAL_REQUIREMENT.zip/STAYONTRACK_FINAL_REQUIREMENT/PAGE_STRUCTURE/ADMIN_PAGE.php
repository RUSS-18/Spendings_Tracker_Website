<?php include('config.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN PAGE</title>
    <link rel="stylesheet" href="admin_page.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link id="theme-link" rel="stylesheet" href="default-theme.css">
    <link rel="stylesheet" href="assets/bootstrap-5.0.2-dist/css/bootstrap.css">
    <script src="assets/bootstrap-5.0.2-dist/js/bootstrap.js"></script>
    <script src="assets/jquery-3.6.4.min.js"></script>
    <script src="theme-toggle.js"></script>
    <script>
    // Retrieve the stored theme when the page loads
    window.addEventListener('DOMContentLoaded', function() {
      var theme = localStorage.getItem('theme');
      if (theme === 'dark') {
        applyDarkTheme();
      }
      });
    </script>
   <script src="theme-toggle.js"></script>
</head>
<body>
    <header class="flex">
      <img src="ICON/blue.png" alt="logo" class="logo_blue">
      <button id="theme-toggle-button" onclick="toggleTheme()" class="default">
         <i id="theme-toggle-icon" class="fas fa-sun"></i>
      </button>
    </header>
   <main>
      <div>
         <input type="checkbox" name="sidebar" id="sidebar">
         <label for="sidebar"><img src="ICON/icons8-menu-50.png" alt="menu" class="menu_icon"></label>
         <div class="navigation">
            <div class="profile">
               
               <?php
               $sql = "SELECT * FROM tbl_tracking";
               $result=$conn->query($sql);
               while($row=$result->fetch(PDO::FETCH_ASSOC)){
               $x = $row['User_Id'];
               }
               $sql = "SELECT * FROM tbl_accounts WHERE ID = $x";
               $result=$conn->query($sql);
               $row = $result->fetch(PDO::FETCH_ASSOC);
               ?>
               <?php  echo "<img alt = 'profile'style='height:100px;width:100px;border-radius:100px'; src='images/".$row['user_pic']."' >"; ?>
               <p><?php echo $row['username'] ?></p>
               <p>*****</p>
            </div>


            <div class="navig">
                  <nav>
                     <a href="ADMIN_PAGE.php"><img class="nav_icon" src="ICON/user.png" alt="user_icon"><span>USERS</span></a>
                     <a href="TRANSACTION-admin.php"><img class="nav_icon" src="ICON/icons8-budgeting-48.png" alt="transac_icon"><span>TRANSACTION</span></a>
                     <a href="CATEGORY-admin.php"><img class="nav_icon" src="ICON/icons8-filing-cabinet-50.png"  alt="category_icon   "><span>CATEGORY</span></a>
                     <br>
                     <br>
                     <a href="SETTINGS-admin.php"><img class="nav_icon" src="ICON/icons8-setting-24.png" alt="settings_icon"><span>SETTINGS</span></a>
                     <a href="FEEDBACK-admin.php"><img class="nav_icon" src="ICON/icons8-about-30.png" alt="feedback_icon"><span>FEEDBACK</span></a>
                     <a href="SIGN_UP_PAGE.php"><img class="nav_icon" src="ICON/icons8-logout-30.png" alt="logout_icon"><span>LOG OUT</span></a>
                  </nav>
            </div>  
         </div>   
      </div>
      <div class="main-content">
         <button type="button" class="btn add_user btn-success" data-bs-toggle="modal" data-bs-target="#addModal"><i class="fa fa-user-plus"></i></button>
         <div class="users-overview">
            <div class="users-card">
               <div>
                  <h1 class="user-title">New User</h1>
               </div>
               <div>
                  <p class="user-total green">44</p>
               </div>
            </div>
            <div class="users-card">
                <div>
                  <h1 class="user-title">Total User</h1>
               </div>
               <div>
                  <p class="user-total blue">33</p>
               </div>
            </div>
            <div class="users-card">
              <div>
                  <h1 class="user-title">Disabled User</h1>
               </div>
               <div>
                  <p class="user-total orange">66</p>
               </div>
            </div>
         </div>

         <div class="user-table-outercase">
            <ul class="user-table-heading">
              <li>User_ID</li>
              <li>Username</li>
              <li>FirstName</li>
              <li>LastName</li>
              <li>Email</li>
              <li>Age</li>
              <li>Password</li>
              <li>Account</li>
              <li>Photo</li>
              <li>Operation</li> 
            </ul>
            <div class="user-table-innercase">
               <table class="user-table">
                  <?php 
 $sql="SELECT * FROM tbl_accounts";
 $result=$conn->query($sql);
 while($row=$result->fetch(PDO::FETCH_ASSOC)){

?>
                  <tr>
                     <td><?php echo $row['ID'];?></td>
                     <td><?php echo $row['username'];?></td>
                     <td><?php echo $row['firstname'];?></td>
                     <td><?php echo $row['lastname'];?></td>
                     <td><?php echo $row['email'];?></td>
                     <td><?php echo $row['age'];?></td>
                     <td><?php echo $row['password'];?></td>
                     <td><?php echo $row['account_type'];?></td>
                     <td><?php   echo "<img style='height:50px;width:50px;border-radius:100px'; src='images/".$row['user_pic']."' >"; ?></td>
                     <td>                            
                        <button class="btn btn-primary btn-sm editbutton" id="<?php echo $user['user_id']; ?>" data-bs-toggle="modal" data-bs-target="#editModal"><i class="fa fa-pen"></i></button>
                        <button class="btn btn-danger btn-sm delbutton" data-bs-toggle="modal" data-bs-target="#delModal" onclick="deletexid(<?php echo $user['user_id']; ?>)"><i class="fa fa-trash"></i></button>
                        <button class="btn btn-warning btn-sm disablebutton" data-bs-toggle="modal" data-bs-target="#disableModal" onclick="disablexid(<?php echo $user['user_id']; ?>)"><i class="fa fa-ban"></i></button>
                     </td>
                  </tr>
                  <?php }?>
               </table>
            </div>
         </div>
      </div>
      <!--add User Modal-->
      <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                  <div class="modal-header">
                     <h5 class="modal-title" id="addModalLabel">Add User</h5>
                     <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                     <form action="" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                              <label for="add-fname" class="form-label">First name</label>
                              <input type="text" class="form-control" id="add-fname" name="fname" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-lname" class="form-label">Last name</label>
                              <input type="text" class="form-control" id="add-lname" name="lname" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-age" class="form-label">Age</label>
                              <input type="number" class="form-control" id="add-age" name="age" min="13" max="120" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-username" class="form-label">Username</label>
                              <input type="text" class="form-control" id="add-username" name="uname" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-email" class="form-label">Email</label>
                              <input type="email" class="form-control" id="add-email" name="email" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-password" class="form-label">Password</label>
                              <input type="password" class="form-control" id="add-password" name="pswd" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-account-type" class="form-label">Account Type</label>
                              <select class="form-select" id="add-account-type" name="acct" required>
                                 <option value="admin">Admin</option>
                                 <option value="user">User</option>
                              </select>
                        </div>
                        <div class="mb-3">
                              <label for="add-profile-pic" class="form-label">Profile Picture</label>
                              <input type="file" class="form-control" id="add-profile-pic" name="image" onchange="previewImage(event)">
                              <br>
                              <img id="preview-image" style="height: 100px; width: 100px; border-radius: 15px; border: 2px groove #efb21e;" alt="Preview Image">
                        </div>
                        <button type="submit" class="btn btn-primary" name="addUser" style="margin-left:24vw;">Add User</button>
                     </form>
                  </div>
            </div>
         </div>
      </div>
      <!--edit Modal-->
      <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                  <div class="modal-header">
                     <h5 class="modal-title" id="editModalLabel">Edit User</h5>
                     <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                     <form action="" method="POST" enctype="multipart/form-data">
                        <input type="hidden" id="edit-user-id" name="uid">
                        <div class="mb-3">
                              <label for="add-fname" class="form-label">First name</label>
                              <input type="text" class="form-control" id="add-fname" name="fname" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-lname" class="form-label">Last name</label>
                              <input type="text" class="form-control" id="add-lname" name="lname" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-age" class="form-label">Age</label>
                              <input type="number" class="form-control" id="add-age" name="age" min="13" max="120" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-username" class="form-label">Username</label>
                              <input type="text" class="form-control" id="add-username" name="uname" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-email" class="form-label">Email</label>
                              <input type="email" class="form-control" id="add-email" name="email" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-password" class="form-label">Password</label>
                              <input type="password" class="form-control" id="add-password" name="pswd" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-account-type" class="form-label">Account Type</label>
                              <select class="form-select" id="add-account-type" name="acct" required>
                                 <option value="admin">Admin</option>
                                 <option value="user">User</option>
                              </select>
                        </div>
                        <div class="mb-3">
                              <label for="edit-profile-pic" class="form-label">Profile Picture</label>
                              <input type="file" class="form-control" id="edit-profile-pic" name="image">
                              <br>
                              <img src="images/<?php echo $user['user_pic']; ?>" id="current-image" style="height: 100px; width: 100px; border-radius: 15px; border: 2px groove #efb21e;" alt="">
                        </div>
                        <button type="submit" class="btn btn-primary" name="editUser" style="margin-left:22vw;">Save Changes</button>
                     </form>
                  </div>
                  <!-- <script>
                     $(document).ready(function() {
                        $(".editbutton").click(function() {
                              var editValue = $(this).attr("id");
                              var username = $(this).closest("tr").find(".username").html();
                              var password = $(this).closest("tr").find(".password").html();
                              var accountType = $(this).closest("tr").find(".accounttype").html();
                              var userPic = $(this).closest("tr").find(".userpic").attr('src');

                              $("#edit-user-id").val(editValue);
                              $("#edit-username").val('<?php echo $user['username']; ?>'); // Set current username
                              $("#edit-password").val('<?php echo $user['password']; ?>'); // Set current password
                              $("#edit-account-type").val('<?php echo $user['account_type']; ?>'); // Set current account type
                              $("#current-image").attr('src', userPic);

                              $('#editModal').modal('show');
                        });
                     });
                  </script> -->
            </div>
         </div>
      </div>
       <!-------------------------- delete Modal -------------------------->
    <div class="modal fade" id="delModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Delete User</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                  <!-- <span aria-hidden="true">&times;</span> -->
                  </button>
              </div>
              <div class="modal-body">
                  <p>Are you sure you want to delete?</p>
              </div>
              <div class="modal-footer">
                  <form action="" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="xid" id="delid">
                    <button type="submit" class="btn btn-primary" name="delUser">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                  </form>
              </div>
            </div>
        </div>
    </div>
     <!-------------------------- disable Modal -------------------------->
     <div class="modal fade" id="disableModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Disable User</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                  <!-- <span aria-hidden="true">&times;</span> -->
                  </button>
              </div>
              <div class="modal-body">
                  <p>Are you sure you want to disable?</p>
              </div>
              <div class="modal-footer">
                  <form action="" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="disxid" id="disableid">
                    <button type="submit" class="btn btn-primary" name="disableUser">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                  </form>
              </div>
            </div>
        </div>
    </div>
</body>
</html>