<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CATEGORY</title>
    <link rel="stylesheet" href="category.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link id="theme-link" rel="stylesheet" href="default-theme.css">
    <script src="theme-toggle.js"></script>
    <script>
    // Retrieve the stored theme when the page loads
    window.addEventListener('DOMContentLoaded', function() {
      var theme = localStorage.getItem('theme');
      if (theme === 'dark') {
        applyDarkTheme();
      }
      });
      
    </script>
</head>
<?php
include('config.php');
$sql = "SELECT * FROM tbl_tracking";
               $result=$conn->query($sql);
               while($row=$result->fetch(PDO::FETCH_ASSOC)){
               $x = $row['User_Id'];
               }

if (isset($_POST['submit'])) {
    if($_POST['subCategory'] == "" ||$_POST['subCategory']== null ){
        echo "<script>alert('Please fill in the textbox')</script>";
    }else if ($_POST['categoryType'] == "Expenses") {
    $sql = "INSERT INTO tbl_subcatexpenses (User_Id,`Sub-category_name`) VALUES (:id,:sub)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':id' => $x,
    ':sub' => $_POST['subCategory']]);
  } else if($_POST['categoryType'] == "Income") {
    $sql = "INSERT INTO tbl_subcatincomes (User_Id,`Sub-category_name`) VALUES (:id,:sub)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':id' => $x,
      ':sub' => $_POST['subCategory']]);
  }
}




        if(isset($_POST['submits'])){
         // $sql= "DELETE FROM tbl_subcatexpenses WHERE `User_Id` = :id";
          $stmt=$conn->prepare($sql);  
          $stmt->execute([':id'=>$_POST['xid']]);
          echo '<script>alert("1 record deleted")</script>';
        }

?>
<style>
    /* Modal styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 1;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0, 0, 0, 0.4);
    }
    
    .modal-content {
      background-color: #fefefe;
      margin: 15% auto;
      padding: 20px;
      border: 1px solid #888;
      width: 300px;
      border-radius: 4px;
    }
    
    .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }
    
    .close:hover,
    .close:focus {
      color: black;
      text-decoration: none;
    }

    /* Style for the input and select */
    input[type="text"],
    select {
      width: 100%;
      padding: 8px;
      margin: 6px 0;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }
    
    /* Style for the buttons */
    button:not(#theme-toggle-button, .default, .btn, .add) {
      background-color: #4CAF50;
      color: white;
      padding: 8px 16px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    
    button:hover {
      background-color: #45a049;
    }

    .add{
        
        font-size:30px;
    }
  </style>
<body>
<header class="flex">
      <img src="ICON/blue.png" alt="logo" class="logo_blue">
      <button id="theme-toggle-button" onclick="toggleTheme()" class="default">
         <i id="theme-toggle-icon" class="fas fa-sun"></i>
      </button>
   </header>
   <main>
   <div>
         <input type="checkbox" name="sidebar" id="sidebar">
         <label for="sidebar"><img src="ICON/icons8-menu-50.png" alt="menu" class="menu_icon"></label>
         <div class="navigation">
            <div class="profile">
               
               <?php
               // fix it, it does not select the current person who login
               include('config.php');
               $sql = "SELECT * FROM tbl_tracking";
               $result=$conn->query($sql);
               while($row=$result->fetch(PDO::FETCH_ASSOC)){
               $x = $row['User_Id'];
               }
               $sql = "SELECT * FROM tbl_accounts WHERE ID = $x";
               $result=$conn->query($sql);
               $row = $result->fetch(PDO::FETCH_ASSOC);
               ?>
               <?php  echo "<img alt = 'profile'style='height:100px;width:100px;border-radius:100px'; src='images/".$row['user_pic']."' >"; ?>
               <p><?php echo $row['username'] ?></p>
               <p>*****</p>
            </div>


            <div class="nav">
                  <nav>
                     <div class="line"></div>
                     <a href="HOMEPAGE.php"><img class="nav_icon" src="ICON/icons8-home-24 (1).png" alt="home_icon"><span>HOME</span></a>
                     <a href="TRANSACTION.php"><img class="nav_icon" src="ICON/icons8-budgeting-48.png" alt="transac_icon"><span>TRANSACTION</span></a>
                     <a href="CATEGORY.php"><img class="nav_icon" src="ICON/icons8-filing-cabinet-50.png" alt="category_icon"><span>CATEGORY</span></a>
                     <a href="TIPS.php"><img class="nav_icon" src="ICON/icons8-bulb-32.png" alt="tips_icon   "><span>TIPS</span></a>
                     <br>
                     <br>
                     <a href="SETTINGS.php"><img class="nav_icon" src="ICON/icons8-setting-24.png" alt="settings_icon"><span>SETTINGS</span></a>
                     <a href="HELP.php"><img class="nav_icon" src="ICON/icons8-about-30.png" alt="help_icon"><span>HELP</span></a>
                     <!-- <div class="line"></div> -->
                     <a href="SIGN_UP_PAGE.php"><img class="nav_icon" src="ICON/icons8-logout-30.png" alt="logout_icon"><span>LOG OUT</span></a>
                  </nav>
            </div>  
         </div>   
      </div>
     
    <div class="main-content">
        <h1 class="subtitle">CATEGORY</h1>
        <hr>
        <div class="housing">
            <?php  
            $sql="SELECT * FROM tbl_subcatexpenses";
            $result=$conn->query($sql);
            while($row=$result->fetch(PDO::FETCH_ASSOC)){
              if($row['User_Id'] == 0 || $x==$row['User_Id']){
                ?>
          <div class="wrapper details">
            <h2><?php echo $row['Sub-category_name'];?></h2>
            <!-- <div class="icon"><i class="fa fa-shopping-cart"></i></div> -->
            <div  class="operations">
              <button class="btn primary btn-sm editbutton" id="<?php echo $row['Sub-category_Id']; ?>" data-bs-toggle="modal" data-bs-target="#editModal"><i class="fa fa-pen"></i></button>
              <button class="btn danger btn-sm delbutton" data-bs-toggle="modal" data-bs-target="#delModal" onclick="deletexid(<?php echo $row['Sub-category_Id']; ?>)"><i class="fa fa-trash"></i></button>

            </div>
          </div>
          <?php }; } ?>

          <?php  
            $sql="SELECT * FROM tbl_subcatincomes";
            $result=$conn->query($sql);
            while($row=$result->fetch(PDO::FETCH_ASSOC)){
              if($row['User_Id'] == 0 || $x==$row['User_Id']){
                ?>
          <div class="wrapper details">
              <h2><?php echo $row['Sub-category_name'];?></h2>
              <div  class="operations">
              <button class="btn primary btn-sm editbutton" id="<?php  echo $row['Sub-category_Id']; ?>" data-bs-toggle="modal" data-bs-target="#editModal"><i class="fa fa-pen"></i></button>
              <button class="btn danger btn-sm delbutton" data-bs-toggle="modal" data-bs-target="#delModal" onclick="deletexid(<?php echo $row['Sub-Category_Id']; ?>)"><i class="fa fa-trash"></i></button>

            </div>
          </div>
          <?php } } ?>

              <button class="add" id="add"><i class="fa fa-cart-plus"></i></button>

        </div>
     <!-- Delete Modal -->
     <div class="modal fade" id="delModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Item</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>Are you sure you want to delete?</p>
      </div>
      <div class="modal-footer">
        <form id="delForm" action="" method="POST" enctype="multipart/form-data">
          <input type="hidden" name="xid" id="delid">
          <button type="button" class="btn btn-secondary" style="color:black" data-bs-dismiss="modal">No</button>
          <button type="submit" name="submits" class="btn btn-primary" style="color:red">Yes</button>
        </form>
      </div>
    </div>
  </div>
</div>






         <!-- Modal -->
  <div id="myModal" class="modal">
    <div class="modal-content">
      <span class="close">&times;</span>
      <form action="" method="POST">
      <label for="subCategory">Sub-category:</label>
      <input type="text" id="subCategory" name="subCategory" placeholder="Enter sub-category">
      <br><br>
      <label for="categoryType">Category Type:</label>
      <select id="categoryType" name="categoryType">
        <option value="Expenses">Expenses</option>
        <option value="Income">Income</option>
      </select>
      <br><br>
      <button type="submit" name="submit">Save</button>
    </div></form>
  </div>
        <footer id="footer">
          <hr>
          <p>Copyright 2022</p>
        </footer>
    </div>
   </main>
</body>

</html>
<script>
    // Get the modal element
    var modal = document.getElementById("myModal");

    // Get the button that opens the modal
    var btn = document.getElementById("add");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // Open the modal when the button is clicked
    btn.onclick = function() {
      modal.style.display = "block";
    }

    // Close the modal when the user clicks on <span> (x)
    span.onclick = function() {
      modal.style.display = "none";
    }

    // Close the modal when the user clicks outside the modal
    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    }
  </script>
  <script>
  // Get the delete modal element
  var delModal = document.getElementById("delModal");

  // Get the delete buttons
  var delButtons = document.getElementsByClassName("delbutton");

  // Get the <span> element that closes the delete modal
  var delClose = document.getElementById("delModalClose");

  // Open the delete modal when a delete button is clicked
  for (var i = 0; i < delButtons.length; i++) {
    delButtons[i].onclick = function() {
      delModal.style.display = "block";
    };
  }

  // Close the delete modal when the user clicks on <span> (x)
  delClose.onclick = function() {
    delModal.style.display = "none";
  };

  // Close the delete modal when the user clicks outside the delete modal
  window.onclick = function(event) {
    if (event.target == delModal) {
      delModal.style.display = "none";
    }
  };

  // Submit the delete form
  var delForm = document.getElementById("delForm");

  delForm.addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission
    var confirmDelete = confirm("Are you sure you want to delete?");
    if (confirmDelete) {
      this.submit(); // Submit the form
    } 
  });
  function deletexid(x) {
      document.getElementById('delid').value = x;
  } 
</script>
