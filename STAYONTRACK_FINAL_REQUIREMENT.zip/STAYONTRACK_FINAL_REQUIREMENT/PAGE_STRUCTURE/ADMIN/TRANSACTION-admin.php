<?php include('config.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TRANSACTION-admin</title>
    <link rel="stylesheet" href="transaction-admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link id="theme-link" rel="stylesheet" href="default-theme.css">
    <link rel="stylesheet" href="assets/bootstrap-5.0.2-dist/css/bootstrap.css">
    <script src="assets/bootstrap-5.0.2-dist/js/bootstrap.js"></script>
    <script src="assets/jquery-3.6.4.min.js"></script>
    <script src="theme-toggle.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
     <script>
    // Retrieve the stored theme when the page loads
    window.addEventListener('DOMContentLoaded', function() {
      var theme = localStorage.getItem('theme');
      if (theme === 'dark') {
        applyDarkTheme();
      }
      });
    </script>
   <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
   <style>
      .chart-container {
         width: 300px; /* Set the desired width */
         height: 300px; /* Set the desired height */
         display: inline-block; /* Display charts side by side */
         margin-right: 20px; /* Add some spacing between the charts */
      }
   </style>
</head>
<body>
    <header class="flex">
      <img src="ICON/blue.png" alt="logo" class="logo_blue">
      <button id="theme-toggle-button" onclick="toggleTheme()" class="default">
         <i id="theme-toggle-icon" class="fas fa-sun"></i>
      </button>
    </header>
   <main>
      <div>
         <input type="checkbox" name="sidebar" id="sidebar">
         <label for="sidebar"><img src="ICON/icons8-menu-50.png" alt="menu" class="menu_icon"></label>
         <div class="navigation">
            <div class="profile">
               
               <?php
               $sql = "SELECT * FROM tbl_tracking";
               $result=$conn->query($sql);
               while($row=$result->fetch(PDO::FETCH_ASSOC)){
               $x = $row['User_Id'];
               }
               $sql = "SELECT * FROM tbl_accounts WHERE ID = $x";
               $result=$conn->query($sql);
               $row = $result->fetch(PDO::FETCH_ASSOC);
               ?>
               <?php  echo "<img alt = 'profile'style='height:100px;width:100px;border-radius:100px'; src='images/".$row['user_pic']."' >"; ?>
               <p><?php echo $row['username'] ?></p>
               <p>*****</p>
            </div>


            <div class="navig">
                  <nav>
                     <a href="ADMIN_PAGE.php"><img class="nav_icon" src="ICON/user.png" alt="user_icon"><span>USERS</span></a>
                     <a href="TRANSACTION-admin.php"><img class="nav_icon" src="ICON/icons8-budgeting-48.png" alt="transac_icon"><span>TRANSACTION</span></a>
                     <a href="CATEGORY-admin.php"><img class="nav_icon" src="ICON/icons8-bulb-32.png" alt="category_icon   "><span>CATEGORY</span></a>
                     <br>
                     <br>
                     <a href="SETTINGS-admin.php"><img class="nav_icon" src="ICON/icons8-setting-24.png" alt="settings_icon"><span>SETTINGS</span></a>
                     <a href="FEEDBACK-admin.php"><img class="nav_icon" src="ICON/icons8-about-30.png" alt="feedback_icon"><span>FEEDBACK</span></a>
                     <a href="SIGN_UP_PAGE.php"><img class="nav_icon" src="ICON/icons8-logout-30.png" alt="logout_icon"><span>LOG OUT</span></a>
                  </nav>
            </div>  
         </div>   
      </div>
      <?php
$arr1 = [];
$arr2 = [];
$count1 = [];
$count2 = [];
$expenses = 0;
$incomes = 0;

$sql = "SELECT * FROM tbl_subcatexpenses";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
   $arr1[$row['Sub-category_Id']] = $row['Sub-category_name'];
}
$sql = "SELECT * FROM tbl_subcatincomes";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
   $arr2[$row['Sub-Category_Id']] = $row['Sub-category_name'];
}

$sql = "SELECT * FROM tbl_spendings";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
   if ($row['Category_Id'] == 1) {
      $expenses++;
      if (isset($arr1[$row['Sub-category_Id']])) {
         if (isset($count1[$row['Sub-category_Id']])) {
            $count1[$row['Sub-category_Id']]++;
         } else {
            $count1[$row['Sub-category_Id']] = 1;
         }
      }
   } else {
      $incomes++;
     if (isset($arr2[$row['Sub-category_Id']])) {
         if (isset($count2[$row['Sub-category_Id']])) {
            $count2[$row['Sub-category_Id']]++;
         } else {
            $count2[$row['Sub-category_Id']] = 1;
         }
      }
   }
}

$totalExpenses = array_sum($count1);
$totalIncomes = array_sum($count2);


foreach ($count1 as $subCategoryId => $count) {
   $percentage = ($count / $totalExpenses) * 100;
   $subCategoryName = $arr1[$subCategoryId];

}


foreach ($count2 as $subCategoryId => $count) {
   $percentage = ($count / $totalIncomes) * 100;
   $subCategoryName = $arr2[$subCategoryId];

}
// Find the least used category
$leastUsedCategory = null;
$leastUsedCount = PHP_INT_MAX;

foreach ($count1 as $subCategoryId => $count) {
   if ($count < $leastUsedCount) {
      $leastUsedCategory = $arr1[$subCategoryId];
      $leastUsedCount = $count;
   }
}

foreach ($count2 as $subCategoryId => $count) {
   if ($count < $leastUsedCount) {
      $leastUsedCategory = $arr2[$subCategoryId];
      $leastUsedCount = $count;
   }
}

// Find the most used category
$mostUsedCategory = null;
$mostUsedCount = 0;

foreach ($count1 as $subCategoryId => $count) {
   if ($count > $mostUsedCount) {
      $mostUsedCategory = $arr1[$subCategoryId];
      $mostUsedCount = $count;
   }
}

foreach ($count2 as $subCategoryId => $count) {
   if ($count > $mostUsedCount) {
      $mostUsedCategory = $arr2[$subCategoryId];
      $mostUsedCount = $count;
   }
}

// Print the least used and most used categories


$total = $expenses + $incomes;

$percentage1 = ($expenses / $total) * 100;
$percentage2 = ($incomes/ $total) * 100;

$colors = generateReadableColors(10); // Generate an array of 10 readable colors

// Function to generate readable colors
function generateReadableColors($count) {
    $colors = [];
    $lightnessThreshold = 0.6; // Adjust this value for desired darkness threshold

    for ($i = 0; $i < $count; $i++) {
        $color = generateRandomColor();
        $lightness = calculateColorLightness($color);

        while ($lightness > $lightnessThreshold) {
            $color = generateRandomColor();
            $lightness = calculateColorLightness($color);
        }

        $colors[] = $color;
    }

    return $colors;
}

// Function to generate a random color
function generateRandomColor() {
    $letters = '0123456789ABCDEF';
    $color = '#';

    // Generate a random six-digit hexadecimal color code
    for ($i = 0; $i < 6; $i++) {
        $color .= $letters[rand(0, 15)];
    }

    return $color;
}

// Function to calculate the lightness of a color
function calculateColorLightness($color) {
    $color = str_replace('#', '', $color);
    $r = hexdec(substr($color, 0, 2));
    $g = hexdec(substr($color, 2, 2));
    $b = hexdec(substr($color, 4, 2));
    $lightness = (max($r, $g, $b) + min($r, $g, $b)) / (2 * 255);

    return $lightness;
}
?>
      <div class="main-content">
         <div class="transac-overview">
            <div class="transac-card">
               <div>
                  <h1 class="transac-title">Most Popular Sub-Category </h1>
               </div>
               <div>
                  <p class="transac-info green"><?php echo $mostUsedCategory;?></p>
               </div>
            </div>
            <div class="transac-card">
                <div>
                  <h1 class="transac-title">Least Popular Sub-Category</h1>
               </div>
               <div>
                  <p class="transac-info blue"><?php echo $leastUsedCategory; ?></p>
               </div>
            </div>
            <div class="transac-card">
              <div>
                  <h1 class="transac-title">Most Common Input</h1>
               </div>
               <div>
                  <p class="transac-info orange">Expenses</p>
               </div>
            </div>
         </div>
         <div class="report flex">
                  <h3 class="summary flex">Report</h3>
                  <div class="chart_housing flex">
                  <div class="chart-container">
                        <canvas id="donutChart1"></canvas>
                     </div>

                     <div class="chart-container">
                        <canvas id="donutChart2"></canvas>
                     </div>

                     <script>
                        // Function to create a donut chart
                        function createDonutChart(labels, values, containerId) {
                           // Get the canvas element
                           const canvas = document.getElementById(containerId);

                           // Set the chart data and options
                           const chartData = {
                           labels: labels,
                           datasets: [{
                              data: values,
                              backgroundColor: [<?php
                         for($x=0;$x<count($colors);$x++){
                           echo "'".$colors[$x]."'".",";
                         }
                        
                        ?>],
                              hoverBackgroundColor: [<?php
                         for($x=0;$x<count($colors);$x++){
                           echo "'".$colors[$x]."'".",";
                         }
                        
                        ?>]
                           }]
                           };

                           const chartOptions = {
                           responsive: true,
                           cutoutPercentage: 70,
                           legend: {
                              display: true,
                              position: 'right', // Set the legend position to 'right'
                              labels: {
                                 fontColor: 'black',
                                 fontSize: 14
                              }
                           }
                           };

                           // Create the donut chart
                           new Chart(canvas, {
                           type: 'doughnut',
                           data: chartData,
                           options: chartOptions
                           });
                        }

                        <?php
                        $q=0;
                        $array =[];
                        $array1=[];
                         foreach ($count1 as $subCategoryId => $count) {
                           $percentage = ($count / $totalExpenses) * 100;
                           $subCategoryName = $arr1[$subCategoryId];
                           $array[$q]=$percentage;
                           $array1[$q]=$subCategoryName;
                           $q++;
                         }
                         
                        ?>
                        // Example values for the first chart
                        const labels1 = [<?php
                         for($x=0;$x<count($array1);$x++){
                           echo "'".$array1[$x]."'".",";
                         }
                        
                        ?>];
                        const values1 = [<?php
                         for($x=0;$x<count($array);$x++){
                           echo $array[$x].",";
                         }
                        
                        ?>];
<?php
$q = 0;
$incomePercentages = []; // Array to store income percentages
$incomeSubcategoryNames = []; // Array to store income subcategory names

foreach ($count2 as $subCategoryId => $count) {
   $percentage = ($count / $totalIncomes) * 100;
   $subCategoryName = $arr2[$subCategoryId];
   $incomePercentages[$q] = $percentage;
   $incomeSubcategoryNames[$q] = $subCategoryName;
   $q++;
}

?>
                        // Create the first donut chart
                        createDonutChart(labels1, values1, 'donutChart1');
                         
                        // Example values for the second chart
                        const labels2 = [<?php
                         for($x=0;$x<count($incomeSubcategoryNames);$x++){
                           echo "'".$incomeSubcategoryNames[$x]."'".",";
                         }
                        
                        ?>];
                        const values2 = [<?php
                         for($x=0;$x<count($incomePercentages);$x++){
                           echo $incomePercentages[$x].",";
                         }
                        
                        ?>];
// Create the second donut chart
                        createDonutChart(labels2, values2, 'donutChart2');
                     </script>
                    
                  </div>
            </div>
         <div class="transac-table-outercase">
            <ul class="transac-table-heading">
               
              <li>Spending_ID</li>
              <li>User_ID</li>
              <li>Category_ID</li>
              <li>Sub-Category ID</li>
              <li>Item_name</li>
              <li>Amount</li>
              <li>Date</li>
            </ul>
            <div class="transac-table-innercase">
               <table class="transac-table">
                  <?php  $sql = "SELECT * FROM tbl_spendings";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {

   ?>
                  <tr>
                     <td><?php echo $row['Spending_Id'];?></td>
                     <td><?php echo $row['User_Id'];?></td>
                     <td><?php echo $row['Category_Id'];?></td>
                     <td><?php echo $row['Sub-category_Id'];?></td>
                     <td><?php echo $row['Item_name'];?></td>
                     <td><?php echo $row['Cost'];?></td>
                     <td><?php echo $row['Date'];?></td>
                  </tr>
                  <?php } ?>
               </table>
            </div>
         </div>
      </div>

</body>
</html>