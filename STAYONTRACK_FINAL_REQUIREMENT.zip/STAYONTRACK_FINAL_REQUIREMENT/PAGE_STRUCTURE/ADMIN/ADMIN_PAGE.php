<?php include('config.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN PAGE</title>
    <link rel="stylesheet" href="admin_page.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link id="theme-link" rel="stylesheet" href="default-theme.css">
    <link rel="stylesheet" href="assets/bootstrap-5.0.2-dist/css/bootstrap.css">
    <script src="assets/bootstrap-5.0.2-dist/js/bootstrap.js"></script>
    <script src="assets/jquery-3.6.4.min.js"></script>
    <script src="theme-toggle.js"></script>
    <script>
    // Retrieve the stored theme when the page loads
    window.addEventListener('DOMContentLoaded', function() {
      var theme = localStorage.getItem('theme');
      if (theme === 'dark') {
        applyDarkTheme();
      }
      });
    </script>
   <script src="theme-toggle.js"></script>
   <?php
     include('config.php');
     if(isset($_POST['addUser'])){
         $filename = $_FILES['image']['name'];
         $tempname = $_FILES['image']['tmp_name'];
         $folder = "./images/" . $filename;
 
         $folder = "./images/" . $filename;
        $sql="INSERT INTO tbl_accounts (username,firstname,lastname,email,age,password,user_pic,account_type) VALUES (:uname, :fname, :lname, :email, :age, :pword, :upic,:acc)";
        $stmt=$conn->prepare($sql);
        $stmt->execute([
        ':uname'=>$_POST['uname'],
        ':fname'=>$_POST['fname'],
        ':lname'=>$_POST['lname'],
        ':email'=>$_POST['email'],
        ':age'=>$_POST['age'],
        ':pword'=>$_POST['pswd'],
        ':upic'=>$filename,
        ':acc'=> $_POST['acct']]);
         move_uploaded_file($tempname, $folder);
         echo '<script>alert("1 record added successfully")</script>';
        }
      // Code to delete User
      if (isset($_POST['delUser'])) {
        @ $userId = $_POST['delid'];
         $sql = "DELETE FROM tbl_accounts WHERE ID=:userid";
         $stmt = $conn->prepare($sql);
         $stmt->execute([':userid' => $userId]);
         echo '<script>alert("1 record deleted")</script>';
      }
      // Edit User
      if (isset($_POST['editUser'])) {
         $sql = "UPDATE tbl_accounts SET username = :uname, firstname = :fname, lastname = :lname, email = :email, password = :pwd, account_type = :acct";
         $params = array(
            ':uname' => $_POST['uname'],
            ':fname' => $_POST['fname'],
            ':lname' => $_POST['lname'],
            ':email' => $_POST['email'],
            ':pwd' => $_POST['pswd'],
            ':acct' => $_POST['acct'],
         );

         // Check if a new image was selected
         if (!empty($_FILES['image']['name'])) {
            $image = $_FILES['image']['name'];
            $tempname = $_FILES['image']['tmp_name'];
            $folder = "images/" . $image;
            $sql .= ", user_pic = :pic";
            $params[':pic'] = $image;
            move_uploaded_file($tempname, $folder);
         } else {    
            // Retrieve the current image from the database
            $stmt = $conn->prepare("SELECT user_pic FROM tbl_accounts WHERE ID = :id");
            $stmt->bindParam(':id', $_POST['uid']);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $image = $row['user_pic'];
         }

         $sql .= " WHERE ID = :id";
         $params[':id'] = $_POST['uid'];
         $stmt = $conn->prepare($sql);
         $stmt->execute($params);
         echo '<script>alert("1 record updated successfully")</script>';
      }
      
         ?>
         <script>
             // Display the newly added user's picture
             var userPic = document.createElement('img');
             userPic.src = "images/<?php echo $newUser['user_pic']; ?>";
             userPic.style.height = '60px';
             userPic.style.width = '60px';
             userPic.style.borderRadius = '15px';
             userPic.style.border = '2px groove #efb21e';
      
             // Append the user picture to the last row in the table
             var lastRow = document.querySelector('table tbody tr:last-child');
             var picCell = document.createElement('td');
             picCell.appendChild(userPic);
             lastRow.appendChild(picCell);
         </script>
         <?php
         

      // Fetch User Data
      $stmt = $conn->query("SELECT * FROM tbl_accounts");   
      $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Add User
?>
   <script>
      function previewImage(event) {
         var input = event.target;
         var preview = document.getElementById("preview-image");

         if (input.files && input.files[0]) {
               var reader = new FileReader();

               reader.onload = function (e) {
                  preview.src = e.target.result;
               };

               reader.readAsDataURL(input.files[0]);
         }
      }
   </script>
</head>
<body>
    <header class="flex">
      <img src="ICON/blue.png" alt="logo" class="logo_blue">
      <button id="theme-toggle-button" onclick="toggleTheme()" class="default">
         <i id="theme-toggle-icon" class="fas fa-sun"></i>
      </button>
    </header>
   <main>
      <div>
         <input type="checkbox" name="sidebar" id="sidebar">
         <label for="sidebar"><img src="ICON/icons8-menu-50.png" alt="menu" class="menu_icon"></label>
         <div class="navigation">
            <div class="profile">
               
            <?php
               // fix it, it does not select the current person who login
               include('config.php');
               $sql = "SELECT * FROM tbl_tracking";
               $result=$conn->query($sql);
               while($row=$result->fetch(PDO::FETCH_ASSOC)){
               $x = $row['User_Id'];
               }
               $sql = "SELECT * FROM tbl_accounts WHERE ID = $x";
               $result=$conn->query($sql);
               $row = $result->fetch(PDO::FETCH_ASSOC);
               ?>
               <?php  echo "<img alt = 'profile'style='height:100px;width:100px;border-radius:100px'; src='images/".$row['user_pic']."' >"; ?>
               <p><?php echo $row['username'] ?></p>
               <p>*****</p>
            </div>
<div class="navig">
                  <nav>
                     <a href="ADMIN_PAGE.php"><img class="nav_icon" src="ICON/user.png" alt="user_icon"><span>USERS</span></a>
                     <a href="TRANSACTION-admin.php"><img class="nav_icon" src="ICON/icons8-budgeting-48.png" alt="transac_icon"><span>TRANSACTION</span></a>
                     <a href="CATEGORY-admin.php"><img class="nav_icon" src="ICON/icons8-filing-cabinet-50.png"  alt="category_icon   "><span>CATEGORY</span></a>
                     <br>
                     <br>
                     <a href="SETTINGS-admin.php"><img class="nav_icon" src="ICON/icons8-setting-24.png" alt="settings_icon"><span>SETTINGS</span></a>
                     <a href="FEEDBACK-admin.php"><img class="nav_icon" src="ICON/icons8-about-30.png" alt="feedback_icon"><span>FEEDBACK</span></a>
                     <a href="SIGN_UP_PAGE.php"><img class="nav_icon" src="ICON/icons8-logout-30.png" alt="logout_icon"><span>LOG OUT</span></a>
                  </nav>
            </div>  
         </div>   
      </div>
      <div class="main-content">
         <button type="button" class="btn add_user btn-success" data-bs-toggle="modal" data-bs-target="#addModal"><i class="fa fa-user-plus"></i></button>
         <div class="users-overview">
            <div class="users-card">
               <div>
                  <h1 class="user-title">New User</h1>
               </div>
               <div>
                  <p class="user-total green"><?php echo count($users); ?></p>
               </div>
            </div>
            <div class="users-card">
                <div>
                  <h1 class="user-title">Total User</h1>
               </div>
               <div>
                  <p class="user-total blue"><?php echo count($users); ?></p>
               </div>
            </div>
            <div class="users-card">
              <div>
                  <h1 class="user-title">Deleted User</h1>
               </div>
               <div>
                  <?php
                  $last;
                  $count =0;
                   $sql = "SELECT * FROM tbl_accounts";
                   $result=$conn->query($sql);
                   while($row=$result->fetch(PDO::FETCH_ASSOC)){
                     $count++;
                     $last = $row['ID'];
                   }
                  ?>
                  <p class="user-total orange"><?php echo $last-$count; ?></p>
                     
                  
               </div>
            </div>
         </div>
<div class="user-table-outercase">
            <ul class="user-table-heading">
              <li class="table-title">USERS</li>
            </ul>
            <div class="user-table-innercase">
               <table class="user-table">
                  <thead>
                     <tr class="user-table-heading">
                        <td>User_ID</td>
                        <td>Username</td>
                        <td>FirstName</td>
                        <td>LastName</td>
                        <td>Email</td>
                        <td>Age</td>
                        <td>Password</td>
                        <td>Account</td>
                        <td>Photo</td>
                        <td>Operation</td> 
                     </tr> 
                  </thead>
            <?php foreach ($users as $user) {?>
                  <tr>
                     <td><?php echo $user['ID']; ?></td>
                     <td><?php echo $user['username']; ?></td>
                     <td><?php echo $user['firstname']; ?></td>
                     <td><?php echo $user['lastname']; ?></td>
                     <td><?php echo $user['email']; ?></td>
                     <td><?php echo $user['age']; ?></td>
                     <td><?php echo $user['password']; ?></td>
                     <td><?php echo $user['account_type']; ?></td>
                     <td>
                        <img src="images/<?php echo $user['user_pic']; ?>" alt="User Picture" class="user-pic"></td>
                     <td>
                        <button class="btn btn-primary btn-sm editbutton"id="<?php echo $user['ID']; ?>" data-bs-toggle="modal" data-bs-target="#editModal"><i class="fa fa-pen"></i></button>
                        <form method="post" style="display: inline-block;">
                           <input type="hidden" name="delid" value="<?php echo $user['ID']; ?>">
                           <button type="submit" name="delUser" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this user?');"><i class="fas fa-trash"></i></button>
                        </form>
                     </td>
                  </tr>
                  <?php }?>
               </table>
            </div>
         </div>
               </table>
            </div>
         </div>
      </div>
      <!--add User Modal-->
      <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                  <div class="modal-header">
                     <h5 class="modal-title" id="addModalLabel">Add User</h5>
                     <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                     <form action="" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                              <label for="add-fname" class="form-label">First name</label>
                              <input type="text" class="form-control" id="add-fname" name="fname" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-lname" class="form-label">Last name</label>
                              <input type="text" class="form-control" id="add-lname" name="lname" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-age" class="form-label">Age</label>
                              <input type="number" class="form-control" id="add-age" name="age" min="13" max="120" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-username" class="form-label">Username</label>
                              <input type="text" class="form-control" id="add-username" name="uname" required>
                        </div>
<div class="mb-3">
                              <label for="add-email" class="form-label">Email</label>
                              <input type="email" class="form-control" id="add-email" name="email" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-password" class="form-label">Password</label>
                              <input type="password" class="form-control" id="add-password" name="pswd" required>
                        </div>
                        <div class="mb-3">
                              <label for="add-account-type" class="form-label">Account Type</label>
                              <select class="form-select" id="add-account-type" name="acct" required>
                                 <option value="admin">Admin</option>
                                 <option value="user">User</option>
                              </select>
                        </div>
                        <div class="mb-3">
                              <label for="add-profile-pic" class="form-label">Profile Picture</label>
                              <input type="file" class="form-control" id="add-profile-pic" name="image" onchange="previewImage(event)">
                              <br>
                              <img id="preview-image" style="height: 100px; width: 100px; border-radius: 15px; border: 2px groove #efb21e;" alt="Preview Image">
                        </div>
                        <button type="submit" class="btn btn-primary" name="addUser" style="margin-left:24vw;">Add User</button>
                     </form>
                  </div>
            </div>
         </div>
      </div>
<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="editModalLabel">Edit User</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body">
            <form action="" method="POST" enctype="multipart/form-data">
               <input type="hidden" id="edit-user-id" name="uid">
               <div class="mb-3">
                  <label for="edit-fname" class="form-label">First name</label>
                  <input type="text" class="form-control" id="edit-fname" name="fname" required>
               </div>
               <div class="mb-3">
                  <label for="edit-lname" class="form-label">Last name</label>
                  <input type="text" class="form-control" id="edit-lname" name="lname" required>
               </div>
               <div class="mb-3">
                  <label for="edit-age" class="form-label">Age</label>
                  <input type="number" class="form-control" id="edit-age" name="age" min="13" max="120" required>
               </div>
               <div class="mb-3">
                  <label for="edit-username" class="form-label">Username</label>
                  <input type="text" class="form-control" id="edit-username" name="uname" required>
               </div>
               <div class="mb-3">
                  <label for="edit-email" class="form-label">Email</label>
                  <input type="email" class="form-control" id="edit-email" name="email" required>
               </div>
               <div class="mb-3">
                  <label for="edit-password" class="form-label">Password</label>
                  <input type="password" class="form-control" id="edit-password" name="pswd" required>
               </div>
               <div class="mb-3">
                  <label for="edit-account-type" class="form-label">Account Type</label>
                  <select class="form-select" id="edit-account-type" name="acct" required>
                     <option value="admin">Admin</option>
                     <option value="user">User</option>
                  </select>
               </div>
               <div class="mb-3">
                  <label for="edit-profile-pic" class="form-label">Profile Picture</label>
                  <input type="file" class="form-control" id="edit-profile-pic" name="image">
                  <br>
                  <img src="" id="edit-current-image" style="height: 100px; width: 100px; border-radius: 15px; border: 2px groove #efb21e;" alt="">
               </div>
               <button type="submit" class="btn btn-primary" name="editUser" style="margin-left:22vw;">Save Changes</button>
            </form>
         </div>
      </div>
   </div>
</div>

<script>
 $(document).ready(function() {
  $(".editbutton").click(function() {
    var editValue = $(this).attr("id");
    var username = $(this).closest("tr").find("td:eq(1)").text();
    var firstname = $(this).closest("tr").find("td:eq(2)").text();
    var lastname = $(this).closest("tr").find("td:eq(3)").text();
    var email = $(this).closest("tr").find("td:eq(4)").text();
    var age = $(this).closest("tr").find("td:eq(5)").text();
    var password = $(this).closest("tr").find("td:eq(6)").text();
    var accountType = $(this).closest("tr").find("td:eq(7)").text().trim();
    var userPic = $(this).closest("tr").find(".user-pic").attr('src');

    $("#edit-user-id").val(editValue);
    $("#edit-username").val(username);
    $("#edit-fname").val(firstname);
    $("#edit-lname").val(lastname);
    $("#edit-email").val(email);
    $("#edit-age").val(age);
    $("#edit-password").val(password);
    $("#edit-account-type").val(accountType.toLowerCase());
    $("#edit-current-image").attr('src', userPic);

    $('#editModal').modal('show');
  });
});

</script>


       <!-------------------------- delete Modal -------------------------->
    <div class="modal fade" id="delModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Delete User</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                  <!-- <span aria-hidden="true">&times;</span> -->
                  </button>
              </div>
              <div class="modal-body">
                  <p>Are you sure you want to delete?</p>
              </div>
              <div class="modal-footer">
                  <form action="" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="xid" id="delid">
                    <button type="submit" class="btn btn-primary" name="delUser">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                  </form>
              </div>
            </div>
        </div>
    </div>
</body>
</html>