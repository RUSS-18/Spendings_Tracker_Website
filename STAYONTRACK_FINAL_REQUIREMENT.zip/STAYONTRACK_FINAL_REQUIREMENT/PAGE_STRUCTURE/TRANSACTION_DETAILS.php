<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TRANSACTION_DETAILS</title>
    <link rel="stylesheet" href="transaction_details.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link id="theme-link" rel="stylesheet" href="default-theme.css">
    <script src="theme-toggle.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
   <style>
      .chart-container {
         width: 250px; /* Set the desired width */
         height: 250px; /* Set the desired height */
         display: inline-block; /* Display charts side by side */
         margin-right: 20px; /* Add some spacing between the charts */
      }
   </style>
    <script>
    // Retrieve the stored theme when the page loads
    window.addEventListener('DOMContentLoaded', function() {
      var theme = localStorage.getItem('theme');
      if (theme === 'dark') {
        applyDarkTheme();
      }
      });
      
    </script>
</head>

<body>
   <header>
<img src="ICON/blue.png" alt="logo" class="logo_blue">
      <button id="theme-toggle-button" onclick="toggleTheme()" class="default">
         <i id="theme-toggle-icon" class="fas fa-sun"></i>
      </button>

  </header>
   <main>
   <div>
         <input type="checkbox" name="sidebar" id="sidebar">
         <label for="sidebar"><img src="ICON/icons8-menu-50.png" alt="menu" class="menu_icon"></label>
         <div class="navigation">
            <div class="profile">
               
               <?php
               // fix it, it does not select the current person who login
               include('config.php');
               $sql = "SELECT * FROM tbl_tracking";
               $result=$conn->query($sql);
               while($row=$result->fetch(PDO::FETCH_ASSOC)){
               $x = $row['User_Id'];
               }
               $sql = "SELECT * FROM tbl_accounts WHERE ID = $x";
               $result=$conn->query($sql);
               $row = $result->fetch(PDO::FETCH_ASSOC);
               ?>
               <?php  echo "<img alt = 'profile'style='height:100px;width:100px;border-radius:100px'; src='images/".$row['user_pic']."' >"; ?>
               <p><?php echo $row['username'] ?></p>
               <p>*****</p>
            </div>


            <div class="nav">
                  <nav>
                     <div class="line"></div>
                     <a href="HOMEPAGE.php"><img class="nav_icon" src="ICON/icons8-home-24 (1).png" alt="home_icon"><span>HOME</span></a>
                     <a href="TRANSACTION.php"><img class="nav_icon" src="ICON/icons8-budgeting-48.png" alt="transac_icon"><span>TRANSACTION</span></a>
                     <a href="CATEGORY.php"><img class="nav_icon" src="ICON/icons8-filing-cabinet-50.png" alt="category_icon"><span>CATEGORY</span></a>
                     <a href="TIPS.php"><img class="nav_icon" src="ICON/icons8-bulb-32.png" alt="tips_icon   "><span>TIPS</span></a>
                     <br>
                     <br>
                     <a href="SETTINGS.php"><img class="nav_icon" src="ICON/icons8-setting-24.png" alt="settings_icon"><span>SETTINGS</span></a>
                     <a href="HELP.php"><img class="nav_icon" src="ICON/icons8-about-30.png" alt="help_icon"><span>HELP</span></a>
                     <!-- <div class="line"></div> -->
                     <a href="SIGN_UP_PAGE.php"><img class="nav_icon" src="ICON/icons8-logout-30.png" alt="logout_icon"><span>LOG OUT</span></a>
                  </nav>
            </div>  
         </div>   
      </div>
     
      <div class="main-content">
         <h1 class="subtitle none">TRASACTION-DETAILS</h1>
         <hr>
         <div class="housing">
         <?php
include('config.php');
$sql = "SELECT * FROM tbl_tracking";
$result=$conn->query($sql);
while($row=$result->fetch(PDO::FETCH_ASSOC)){
$x = $row['User_Id'];
}
$sql = "SELECT * FROM tbl_accounts WHERE ID = $x";
$result=$conn->query($sql);
$row = $result->fetch(PDO::FETCH_ASSOC);

$sql = "SELECT * FROM tbl_spendings WHERE User_Id = $x";
$result = $conn->query($sql);
$enddate; 
$startdate;
$last;
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
$enddate = $row['Date'];
$last = $row['Spending_Id'];
}
$sql = "SELECT * FROM tbl_spendings WHERE User_Id = $x";
   $result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
if(!isset($startdate)){
$startdate = $row['Date'];

}
}
   $sql = "SELECT * FROM tbl_spendings WHERE User_Id = $x";
   $result = $conn->query($sql);
   $sum =0;
   $onetime = false;
   @$temp = new DateTime($startdate);
    $temps = clone $temp; 
    $temps2 = clone $temp;
   while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
// Add one week to the cloned object for the next iteration
if($onetime == false){
  $temps->add(new DateInterval('P1W'));
  $onetime = true;
}

  $a = $temps->format('m/d/Y');  

   if($row['Date']<$a && $row['Spending_Id'] != $last){
    if($row['Category_Id'] == 1){
      $sum+=$row['Cost'];
   }
   } else if($row['Spending_Id'] == $last){  
    if($row['Category_Id'] == 1){
      $sum+=$row['Cost'];
   }
    $dateInWords2 = $temps2->format('F j, Y');
    $dateInWords = $temps->format('F j, Y');
    $MONTH = $temps2->format('F j, Y');
    }} 
               ?>
           <h1 class="date none"><?php 
                  if(isset($MONTH)){
                  echo $MONTH." - ".$dateInWords;
                  }else{
                     echo 'MONTH';
                  }

                  ?></h1>
           <div class="wrapper">
              <div class="chart_housing">
              <div class="chart-container">
                        <canvas id="donutChart1"></canvas>
                     </div>
                     <?php
$arr1 = [];
$arr2 = [];
$count1 = [];
$count2 = [];
$expenses = 0;
$incomes = 0;

$sql = "SELECT * FROM tbl_subcatexpenses";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
   $arr1[$row['Sub-category_Id']] = $row['Sub-category_name'];
}
$sql = "SELECT * FROM tbl_subcatincomes";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
   $arr2[$row['Sub-Category_Id']] = $row['Sub-category_name'];
}

$sql = "SELECT * FROM tbl_spendings";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
   if ($row['Category_Id'] == 1) {
      $expenses++;
      if (isset($arr1[$row['Sub-category_Id']])) {
         if (isset($count1[$row['Sub-category_Id']])) {
            $count1[$row['Sub-category_Id']]++;
         } else {
            $count1[$row['Sub-category_Id']] = 1;
         }
      }
   } else {
      $incomes++;
     if (isset($arr2[$row['Sub-category_Id']])) {
         if (isset($count2[$row['Sub-category_Id']])) {
            $count2[$row['Sub-category_Id']]++;
         } else {
            $count2[$row['Sub-category_Id']] = 1;
         }
      }
   }
}

$totalExpenses = array_sum($count1);
$totalIncomes = array_sum($count2);


foreach ($count1 as $subCategoryId => $count) {
   $percentage = ($count / $totalExpenses) * 100;
   $subCategoryName = $arr1[$subCategoryId];

}


foreach ($count2 as $subCategoryId => $count) {
   $percentage = ($count / $totalIncomes) * 100;
   $subCategoryName = $arr2[$subCategoryId];

}
// Find the least used category
$leastUsedCategory = null;
$leastUsedCount = PHP_INT_MAX;

foreach ($count1 as $subCategoryId => $count) {
   if ($count < $leastUsedCount) {
      $leastUsedCategory = $arr1[$subCategoryId];
      $leastUsedCount = $count;
   }
}

foreach ($count2 as $subCategoryId => $count) {
   if ($count < $leastUsedCount) {
      $leastUsedCategory = $arr2[$subCategoryId];
      $leastUsedCount = $count;
   }
}

// Find the most used category
$mostUsedCategory = null;
$mostUsedCount = 0;

foreach ($count1 as $subCategoryId => $count) {
   if ($count > $mostUsedCount) {
      $mostUsedCategory = $arr1[$subCategoryId];
      $mostUsedCount = $count;
   }
}

foreach ($count2 as $subCategoryId => $count) {
   if ($count > $mostUsedCount) {
      $mostUsedCategory = $arr2[$subCategoryId];
      $mostUsedCount = $count;
   }
}

// Print the least used and most used categories


$total = $expenses + $incomes;

$percentage1 = ($expenses / $total) * 100;
$percentage2 = ($incomes/ $total) * 100;

$colors = generateReadableColors(10); // Generate an array of 10 readable colors

// Function to generate readable colors
function generateReadableColors($count) {
    $colors = [];
    $lightnessThreshold = 0.6; // Adjust this value for desired darkness threshold

    for ($i = 0; $i < $count; $i++) {
        $color = generateRandomColor();
        $lightness = calculateColorLightness($color);

        while ($lightness > $lightnessThreshold) {
            $color = generateRandomColor();
            $lightness = calculateColorLightness($color);
        }

        $colors[] = $color;
    }

    return $colors;
}

// Function to generate a random color
function generateRandomColor() {
    $letters = '0123456789ABCDEF';
    $color = '#';

    // Generate a random six-digit hexadecimal color code
    for ($i = 0; $i < 6; $i++) {
        $color .= $letters[rand(0, 15)];
    }

    return $color;
}

// Function to calculate the lightness of a color
function calculateColorLightness($color) {
    $color = str_replace('#', '', $color);
    $r = hexdec(substr($color, 0, 2));
    $g = hexdec(substr($color, 2, 2));
    $b = hexdec(substr($color, 4, 2));
    $lightness = (max($r, $g, $b) + min($r, $g, $b)) / (2 * 255);

    return $lightness;
}
$sql = "SELECT * FROM tbl_tracking";
    $result=$conn->query($sql);
    while($row=$result->fetch(PDO::FETCH_ASSOC)){
    $x = $row['User_Id'];
    }
    $userSubcategoryAmounts = []; // Array to store subcategory amounts for the user

    foreach ($count1 as $subCategoryId => $count) {
       $percentage = ($count / $totalExpenses) * 100;
       $subCategoryName = $arr1[$subCategoryId];
       $userSubcategoryAmounts[$subCategoryName] = 0; // Initialize amount as 0
    }
    
    foreach ($count2 as $subCategoryId => $count) {
       $percentage = ($count / $totalIncomes) * 100;
       $subCategoryName = $arr2[$subCategoryId];
       $userSubcategoryAmounts[$subCategoryName] = 0; // Initialize amount as 0
    }
    
    $userId = $x; // Replace $x with the actual User_Id
    
    $sql = "SELECT * FROM tbl_spendings WHERE User_Id = :userId";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':userId', $userId);
    $stmt->execute();
    

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
       $subCategoryId = $row['Sub-category_Id'];
       $category = $row['Category_Id'];
       $amount = $row['Cost'];
    
       if ($category == 1 && isset($arr1[$subCategoryId])) {
          $subCategoryName = $arr1[$subCategoryId];
          $userSubcategoryAmounts[$subCategoryName] += $amount;
       } elseif ($category == 2 && isset($arr2[$subCategoryId])) {
          $subCategoryName = $arr2[$subCategoryId];
          $userSubcategoryAmounts[$subCategoryName] += $amount;
       }
    }
    

 
?>
      
                 <div class="chart_content">
                 <?php
                        $colorss = [];
                        $control = 0;
                     $sql = "SELECT subcat.`Sub-category_name`, SUM(spending.cost) AS subcategory_total
                     FROM tbl_spendings spending
                     INNER JOIN tbl_subcatexpenses subcat ON spending.`Sub-category_Id` = subcat.`Sub-category_Id`
                     WHERE spending.`Category_Id` = 1 AND spending.`User_Id` = :userId
                     GROUP BY spending.`Sub-category_Id`";
             
             $stmt = $conn->prepare($sql);
             $stmt->execute(['userId' => $x]);
             
             // Calculate the total expenses
             $totalExpenses = 0;
             while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                 $totalExpenses += $row['subcategory_total'];
             }
             
             // Calculate and print the percentage of each subcategory
             $stmt->execute(['userId' => $x]);
             while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                 $subcategoryName = $row['Sub-category_name'];
                 $subcategoryTotal = $row['subcategory_total'];
                 $percentage = ($subcategoryTotal / $totalExpenses) * 100;
                 $percentage = number_format($percentage, 2); // Substring to 2 decimal places
                 $hue = mt_rand(0, 360);
                 $saturation = mt_rand(40, 100);
                 $lightness = mt_rand(30, 70);
             
                 // Convert HSL to RGB
                 $rgb = hslToRgb($hue, $saturation, $lightness);
             
                 // Format the RGB values as a hexadecimal color code
                 $color = sprintf('#%02X%02X%02X', $rgb[0], $rgb[1], $rgb[2]);
             
                 // Add the color to the array
                 array_push($colors, $color);

                  
                  
                        ?> <?php $control++; } ?>
                    
                       
                 </div>
              </div>
             <div class="expense_label flex">
                 <?php
               $expense = 0;
               $income = 0;
                    $sql = "SELECT * FROM tbl_settings WHERE User_Id = $x";
                    $result = $conn->query($sql);
                    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                     $budget = $row['budget'];
                   } 
                   $sql = "SELECT * FROM tbl_spendings WHERE User_Id = $x";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
if($row['Category_Id'] == 1){
   $expense = $expense+$row['Cost'];
}else{
   $income = $income+$row['Cost'];
}
}
if(isset($budget)){
               ?>
                  <h3 class="expense_label"></i>Expense<span class="right red"><?php echo $expense; ?></span></h3>
                  <h3 class="expense_label">Budget<span class="right blue"><?php echo $budget; ?></span></h3>
                  <hr>
                  <h3 class="expense_label">Balance<span class="right green"><?php echo $budget - $expense;?> </span></h3>
                  <?php } else if (isset($income)){?>
                     <h3 class="expense_label"></i>Expense<span class="right red"><?php echo $expense; ?></span></h3>
                  <h3 class="expense_label">Income<span class="right blue"><?php echo $income; ?></span></h3>
                  <hr>
                  <h3 class="expense_label">Balance<span class="right green"><?php echo $income - $expense;?> </span></h3>
                  <?php }else{?>
                     <h3 class="expense_label"></i>Expense<span class="right red">0</span></h3>
                  <h3 class="expense_label">Budget<span class="right blue">0</span></h3>
                  <hr>
                  <h3 class="expense_label">Balance<span class="right green">0 </span></h3>
                  <?php } ?>
             </div>
           </div>
         </div>
         <table>
            <caption>Expenses</caption>
           <thead>
              <th>
                 <tr>
                 <td>Name</td>
            <td>Category</td>  
            <td>Sub-Category</td> 
            <td>Amount</td> 
            <td> Date</td> 

                 </tr>
              </th>
           </thead>
           <tbody>
           <?php

$sql = "SELECT * FROM tbl_spendings WHERE User_Id = $x";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
$sid = $row['Sub-category_Id'];
$id = $row['Category_Id'];
?>
                  <tr>
                     <td><?php echo $row['Item_name']; ?></td>
                     <td><?php 
                     if($id == 1)echo "Expenses";
                     else echo 'Incomes';
                     ?></td>
                     <?php 
      if ($id == 1) {
         $sqls = "SELECT * FROM tbl_subcatexpenses WHERE `Sub-category_Id` = $sid";
         $results = $conn->query($sqls);
         while ($rows = $results->fetch(PDO::FETCH_ASSOC)) {
            echo  "<td>".$rows['Sub-category_name']."</td>";
         }
      } else if ($id == 2) {
         $sqls = "SELECT * FROM tbl_subcatincomes WHERE `Sub-Category_Id` = $sid";
         $results = $conn->query($sqls);
         while ($rows = $results->fetch(PDO::FETCH_ASSOC)) {
           echo  "<td>".$rows['Sub-category_name']."</td>";
         }
      }
      ?>
                     <td><?php echo $row['Cost']; ?></td>
                     <td><?php echo $row['Date']; ?></td>


                  </tr>
                  <?php
}
?>
           </tbody>
        </table>
         <footer id="footer">
           <hr>
           <p>Copyright 2022</p>
         </footer>
      </div>
   </main>
</body>
<?php
function hslToRgb($h, $s, $l) {
   $h /= 360;
   $s /= 100;
   $l /= 100;

   $r = $l;
   $g = $l;
   $b = $l;
   $v = ($l <= 0.5) ? ($l * (1.0 + $s)) : ($l + $s - $l * $s);
   if ($v > 0) {
       $m=null;
       $sv=null;
       $sextant=null;
       $fract=null;
       $vsf=null;
       $mid1=null;
       $mid2=null;

       $m = $l + $l - $v;
       $sv = ($v - $m) / $v;
       $h *= 6.0;
       $sextant = floor($h);
       $fract = $h - $sextant;
       $vsf = $v * $sv * $fract;
       $mid1 = $m + $vsf;
       $mid2 = $v - $vsf;

       switch ($sextant) {
           case 0:
               $r = $v;
               $g = $mid1;
               $b = $m;
               break;
           case 1:
               $r = $mid2;
               $g = $v;
               $b = $m;
               break;
           case 2:
               $r = $m;
               $g = $v;
               $b = $mid1;
               break;
           case 3:
               $r = $m;
               $g = $mid2;
               $b = $v;
               break;
           case 4:
               $r = $mid1;
               $g = $m;
               $b = $v;
               break;
           case 5:
               $r = $v;
               $g = $m;
               $b = $mid2;
               break;
       }
   }

   $r = round($r * 255);
   $g = round($g * 255);
   $b = round($b * 255);

   return array($r, $g, $b);
}
?>


</html>
<script>
                        // Function to create a donut chart
                        function createDonutChart(labels, values, containerId) {
                           // Get the canvas element
                           const canvas = document.getElementById(containerId);

                           // Set the chart data and options
                           const chartData = {
                           labels: labels,
                           datasets: [{
                              data: values,
                              backgroundColor: [<?php
                         for($x=0;$x<count($colors);$x++){
                           echo "'".$colors[$x]."'".",";
                         }
                        
                        ?>],
                              hoverBackgroundColor: [<?php
                         for($x=0;$x<count($colors);$x++){
                           echo "'".$colors[$x]."'".",";
                         }
                        
                        ?>]
                           }]
                           };

                           const chartOptions = {
                           responsive: true,
                           cutoutPercentage: 70,
                           legend: {
                              display: true,
                              position: 'right', // Set the legend position to 'right'
                              labels: {
                                 fontColor: 'black',
                                 fontSize: 14
                              }
                           }
                           };

                           // Create the donut chart
                           new Chart(canvas, {
                           type: 'doughnut',
                           data: chartData,
                           options: chartOptions
                           });
                        }

                        // Example values for the first chart
                        const labels1 = [<?php
                         foreach ($userSubcategoryAmounts as $subCategoryName => $amount) {
                           if($amount != 0){
                           echo "'".$subCategoryName."'".",";
                        }
                        }
                        ?>];
                        const values1 = [<?php
                         foreach ($userSubcategoryAmounts as $subCategoryName => $amount) {
                           if($amount != 0){
                           echo $amount.",";
                        }
                        }
                        ?>];
                        
                        // Create the first donut chart
                        createDonutChart(labels1, values1, 'donutChart1');

                        
                     </script>