<?php include('config.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FEEDBACK-admin</title>
    <link rel="stylesheet" href="feedback-admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link id="theme-link" rel="stylesheet" href="default-theme.css">
    <link rel="stylesheet" href="assets/bootstrap-5.0.2-dist/css/bootstrap.css">
    <script src="assets/bootstrap-5.0.2-dist/js/bootstrap.js"></script>
    <script src="assets/jquery-3.6.4.min.js"></script>
    <script src="theme-toggle.js"></script>
    <script>
    // Retrieve the stored theme when the page loads
    window.addEventListener('DOMContentLoaded', function() {
      var theme = localStorage.getItem('theme');
      if (theme === 'dark') {
        applyDarkTheme();
      }
      });
    </script>
   <script src="theme-toggle.js"></script>
</head>
<body>
    <header class="flex">
      <img src="ICON/blue.png" alt="logo" class="logo_blue">
      <button id="theme-toggle-button" onclick="toggleTheme()" class="default">
         <i id="theme-toggle-icon" class="fas fa-sun"></i>
      </button>
    </header>
    <main>
        <div>
            <input type="checkbox" name="sidebar" id="sidebar">
            <label for="sidebar"><img src="ICON/icons8-menu-50.png" alt="menu" class="menu_icon"></label>
            <div class="navigation">
                <div class="profile">
                
                <?php
                $sql = "SELECT * FROM tbl_tracking";
                $result=$conn->query($sql);
                while($row=$result->fetch(PDO::FETCH_ASSOC)){
                $x = $row['User_Id'];
                }
                $sql = "SELECT * FROM tbl_accounts WHERE ID = $x";
                $result=$conn->query($sql);
                $row = $result->fetch(PDO::FETCH_ASSOC);
                ?>
                <?php  echo "<img alt = 'profile'style='height:100px;width:100px;border-radius:100px'; src='images/".$row['user_pic']."' >"; ?>
                <p><?php echo $row['username'] ?></p>
                <p>*****</p>
                </div>


                <div class="navig">
                    <nav>
                        <a href="ADMIN_PAGE.php"><img class="nav_icon" src="ICON/user.png" alt="user_icon"><span>USERS</span></a>
                        <a href="TRANSACTION-admin.php"><img class="nav_icon" src="ICON/icons8-budgeting-48.png" alt="transac_icon"><span>TRANSACTION</span></a>
                        <a href="CATEGORY-admin.php"><img class="nav_icon" src="ICON/icons8-filing-cabinet-50.png"  alt="category_icon   "><span>CATEGORY</span></a>
                        <br>
                        <br>
                        <a href="SETTINGS-admin.php"><img class="nav_icon" src="ICON/icons8-setting-24.png" alt="settings_icon"><span>SETTINGS</span></a>
                        <a href="FEEDBACK-admin.php"><img class="nav_icon" src="ICON/icons8-about-30.png" alt="feedback_icon"><span>FEEDBACK</span></a>
                        <a href="SIGN_UP_PAGE.php"><img class="nav_icon" src="ICON/icons8-logout-30.png" alt="logout_icon"><span>LOG OUT</span></a>
                    </nav>
                </div>  
            </div>   
        </div>
        <div class="main-content">
            <div class="feedback-table-innercase">
                <h1>User Feedback</h1>
                <table class="feedback-table">
                    <tr data-bs-toggle="modal" data-bs-target="#feedbackModal">
                        <td class="user_id"></td>
                        <td class="feedback-content">dgdg</td>
                    </tr>
                </table>
            </div>
        </div>
    </main>
    <div class="modal fade" id="feedbackModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">User Feedback</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                  <!-- <span aria-hidden="true">&times;</span> -->
                  </button>
              </div>
              <div class="modal-body">
                  <p class="feedback">Wow, ang gulo</p>
              </div>
              <div class="modal-footer">
                  <form action="" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="feedid" id="feedbackid">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Done</button>
                  </form>
              </div>
            </div>
        </div>
    </div>
</body>
</html> 