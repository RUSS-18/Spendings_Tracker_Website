
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOMEPAGE</title>
    <link rel="stylesheet" href="Homepage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link id="theme-link" rel="stylesheet" href="default-theme.css">
    <link rel="stylesheet" href="assets/bootstrap-5.0.2-dist/css/bootstrap.css">
    <script src="assets/bootstrap-5.0.2-dist/js/bootstrap.js"></script>
    <script src="assets/jquery-3.6.4.min.js"></script>

    <script>
    // Retrieve the stored theme when the page loads
    window.addEventListener('DOMContentLoaded', function() {
      var theme = localStorage.getItem('theme');
      if (theme === 'dark') {
        applyDarkTheme();
      }
      });
      
    function updateDateTime() {
      var now = new Date();
      var dateTimeElement = document.getElementById("datetime");
      dateTimeElement.innerHTML = now.toLocaleString();
    }

    function setCustomDateTime() {
      var customDateTimeElement = document.getElementById("custom-datetime");
      var selectedDateTime = new Date(customDateTimeElement.value);
      if (!isNaN(selectedDateTime.getTime())) {
        var dateTimeElement = document.getElementById("datetime");
        dateTimeElement.innerHTML = selectedDateTime.toLocaleString();
      }
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);
  </script>
  <!--CALCULATOR SCRIPT-->
  <script>
      var currentNumber = '';

      function appendValue(value) {
         currentNumber += value;
         document.getElementById('currentNumber').value = currentNumber;
      }

      function calculate() {
         var result = eval(currentNumber);
         document.getElementById('currentNumber').value = result;
         currentNumber = result.toString();
      }

      function clearInput() {
         currentNumber = '';
         document.getElementById('currentNumber').value = '';
      }

      function deleteLastCharacter() {
         currentNumber = currentNumber.slice(0, -1);
         document.getElementById('currentNumber').value = currentNumber;
      }

      // Event listener for keyboard input
      document.addEventListener('keydown', function(event) {
         var key = event.key;
         if (!isNaN(key) || key === '+' || key === '-' || key === '*' || key === '/' || key === '.') {
            appendValue(key);
         } else if (key === 'Enter') {
            calculate();
         } else if (key === 'Backspace') {
            deleteLastCharacter();
         }
      });

      function addItemToTable() {
  var itemInput = document.getElementById("item_name");
  var AmountInput = document.getElementById("currentNumber");
  var categoryDropdown = document.getElementById("category_name");
  var subCategoryDropdown = document.getElementById("sub-category_name");
  var itemTable = document.getElementById("item_table");
  var dateInput = document.getElementById("custom-datetime");

  var item = itemInput.value;
  var category = categoryDropdown.value;
  var subCategory = subCategoryDropdown.value;
  var amount = AmountInput.value;
  var date = dateInput.value;     
      
         
  // Check if the date input field is empty
  if (date === "") {
    var currentDate = new Date();
    var options = {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      hour12: true
    };
    date = currentDate.toLocaleString("en-US", options).replace(/, /, ', ');
  } else {
    var dateObject = new Date(date);
    var options = {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      hour12: true
    };
    date = dateObject.toLocaleString("en-US", options);
  }

  var xhr = new XMLHttpRequest();
  xhr.open('POST', 'saveToFile.php', true);
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  xhr.onreadystatechange = function() {
    if (xhr.readyState === XMLHttpRequest.DONE) {
      if (xhr.status === 200) {
        console.log('Text data saved successfully.');
      } else {
        console.error('Error saving text data:', xhr.status);
      }
    }
  };
  
  var params = 'item=' + encodeURIComponent(item) +
               '&category=' + encodeURIComponent(category) +
               '&subCategory=' + encodeURIComponent(subCategory) +
               '&amount=' + encodeURIComponent(amount) +
               '&date=' + encodeURIComponent(date);
  
  xhr.send(params); 

  if ( category !== "" && subCategory !== "" && amount !== "") {
    var row = itemTable.insertRow(-1);
    var itemCell = row.insertCell(0);
    var categoryCell = row.insertCell(1);
    var subCategoryCell = row.insertCell(2);
    var amountCell = row.insertCell(3);
    var dateCell = row.insertCell(4);

    itemCell.innerHTML = item;
    categoryCell.innerHTML = category;
    subCategoryCell.innerHTML = subCategory;
    amountCell.innerHTML = amount;
    dateCell.innerHTML = date;

    // Clear input fields
    itemInput.value = "";
    categoryDropdown.selectedIndex = 0;
    subCategoryDropdown.selectedIndex = 0;
    dateInput.value = "";
    clearInput();
  } else {
    alert("Please fill in all fields");
  }

 
  
}

function saveTextToFile() {
   var xhr = new XMLHttpRequest();
  xhr.open('GET', 'insert.php', true);
  xhr.onreadystatechange = function() {
    if (xhr.readyState === XMLHttpRequest.DONE) {
      if (xhr.status === 200) {
        console.log('PHP code executed successfully.');
        // Additional code to handle the response from insert.php if needed
      } else {
        console.error('Error executing PHP code:', xhr.status);
      }
    }
  };
  xhr.send();

  var itemTable = document.getElementById("item_table");
itemTable.innerHTML = "";

document.location.reload();
  
      
}



      function updateSubCategoryOptions() {
    var categoryDropdown = document.getElementById("category_name");
    var subCategoryDropdown = document.getElementById("sub-category_name");
    var subCategoryContainer = document.getElementById("sub-category-container");

    if (categoryDropdown.value === "Expenses") {
        <?php 
        include('config.php');
        $sql = "SELECT * FROM tbl_subcatexpenses";
        $result = $conn->query($sql);
        $options = "";

        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $subCategoryName = $row['Sub-category_name'];
            $options .= "<option value=\"$subCategoryName\">$subCategoryName</option>";
        }
        ?>

        subCategoryDropdown.innerHTML = `
            <option value="" disabled selected>Select Sub-Category</option>
            <?php echo $options; ?>
        `;
    } else if (categoryDropdown.value === "Income") {
      <?php 
        include('config.php');
        $sql = "SELECT * FROM tbl_subcatincomes";
        $result = $conn->query($sql);
        $options = "";

        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $subCategoryName = $row['Sub-category_name'];
            $options .= "<option value=\"$subCategoryName\">$subCategoryName</option>";
        }
        ?>

        subCategoryDropdown.innerHTML = `
            <option value="" disabled selected>Select Sub-Category</option>
            <?php echo $options; ?>
        `;
    }

    subCategoryContainer.style.display = "block";
}
   </script>   
</head>
<body>
<header class="flex">
      <img src="ICON/blue.png" alt="logo" class="logo_blue">
      <button id="theme-toggle-button" onclick="toggleTheme()" class="default">
         <i id="theme-toggle-icon" class="fas fa-sun"></i>
      </button>
    </header>
   <main>
      <div class="flex shadow outside_expense">
         <h3 class="expense_label">Expense<span class="right red">3,400</span></h3>
         <h3 class="expense_label">Budget<span class="right blue">5,000</span></h3>
         <hr>
      </div>
      <div>
         <input type="checkbox" name="sidebar" id="sidebar">
         <label for="sidebar"><img src="ICON/icons8-menu-50.png" alt="menu" class="menu_icon"></label>
         <div class="navigation">
            <div class="profile">
               
               <?php
               // fix it, it does not select the current person who login
               include('config.php');
               $sql = "SELECT * FROM tbl_tracking";
               $result=$conn->query($sql);
               while($row=$result->fetch(PDO::FETCH_ASSOC)){
               $x = $row['User_Id'];
               }
               $sql = "SELECT * FROM tbl_accounts WHERE ID = $x";
               $result=$conn->query($sql);
               $row = $result->fetch(PDO::FETCH_ASSOC);
               ?>
               <?php  echo "<img alt = 'profile'style='height:100px;width:100px;border-radius:100px'; src='images/".$row['user_pic']."' >"; ?>
               <p><?php echo $row['username'] ?></p>
               <p>*****</p>
            </div>


            <div class="nav">
                  <nav>
                     <div class="line"></div>
                     <a href="HOMEPAGE.php"><img class="nav_icon" src="ICON/icons8-home-24 (1).png" alt="home_icon"><span>HOME</span></a>
                     <a href="TRANSACTION.php"><img class="nav_icon" src="ICON/icons8-budgeting-48.png" alt="transac_icon"><span>TRANSACTION</span></a>
                     <a href="CATEGORY.php"><img class="nav_icon" src="ICON/icons8-filing-cabinet-50.png" alt="category_icon"><span>CATEGORY</span></a>
                     <a href="TIPS.php"><img class="nav_icon" src="ICON/icons8-bulb-32.png" alt="tips_icon   "><span>TIPS</span></a>
                     <br>
                     <br>
                     <a href="SETTINGS.php"><img class="nav_icon" src="ICON/icons8-setting-24.png" alt="settings_icon"><span>SETTINGS</span></a>
                     <a href="HELP.php"><img class="nav_icon" src="ICON/icons8-about-30.png" alt="help_icon"><span>HELP</span></a>
                     <!-- <div class="line"></div> -->
                     <a href="SIGN_UP_PAGE.php"><img class="nav_icon" src="ICON/icons8-logout-30.png" alt="logout_icon"><span>LOG OUT</span></a>
                  </nav>
            </div>  
         </div>   
      </div>
     
      <div class="main-content"> 
          <div class="quote-casing">
            <h1 id="quote"></h1>
         </div>
            <hr>
         <div class="housing flex">
            <div class="report flex shadow">
               <?php
include('config.php');
$sql = "SELECT * FROM tbl_tracking";
$result=$conn->query($sql);
while($row=$result->fetch(PDO::FETCH_ASSOC)){
$x = $row['User_Id'];
}
$sql = "SELECT * FROM tbl_accounts WHERE ID = $x";
$result=$conn->query($sql);
$row = $result->fetch(PDO::FETCH_ASSOC);

$sql = "SELECT * FROM tbl_spendings WHERE User_Id = $x";
$result = $conn->query($sql);
$enddate; 
$startdate;
$last;
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
$enddate = $row['Date'];
$last = $row['Spending_Id'];
}
$sql = "SELECT * FROM tbl_spendings WHERE User_Id = $x";
   $result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
if(!isset($startdate)){
$startdate = $row['Date'];

}
}
   $sql = "SELECT * FROM tbl_spendings WHERE User_Id = $x";
   $result = $conn->query($sql);
   $sum =0;
   $onetime = false;
   @$temp = new DateTime($startdate);
    $temps = clone $temp; 
    $temps2 = clone $temp;
   while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
// Add one week to the cloned object for the next iteration
if($onetime == false){
  $temps->add(new DateInterval('P1W'));
  $onetime = true;
}

  $a = $temps->format('m/d/Y');  

   if($row['Date']<$a && $row['Spending_Id'] != $last){
    if($row['Category_Id'] == 1){
      $sum+=$row['Cost'];
   }
   } else if($row['Spending_Id'] == $last){  
    if($row['Category_Id'] == 1){
      $sum+=$row['Cost'];
   }
    $dateInWords2 = $temps2->format('F j, Y');
    $dateInWords = $temps->format('F j, Y');
    $MONTH = $temps2->format('F');
    }} 
               ?>
                  <h3 class="summary flex">Recent Summary<span> <?php 
                  if(isset($MONTH)){
                  echo $MONTH;
                  }else{
                     echo 'MONTH';
                  }
                  
                  ?></span></h3>
                  <div class="chart_housing flex">
                     <div class="chart flex">
                        <div class="inchart">

                        </div>
                     </div>
                     <div class="chart_content">
                        <?php
                        $colors = [];
                        $control = 0;
                     $sql = "SELECT subcat.`Sub-category_name`, SUM(spending.cost) AS subcategory_total
                     FROM tbl_spendings spending
                     INNER JOIN tbl_subcatexpenses subcat ON spending.`Sub-category_Id` = subcat.`Sub-category_Id`
                     WHERE spending.`Category_Id` = 1 AND spending.`User_Id` = :userId
                     GROUP BY spending.`Sub-category_Id`";
             
             $stmt = $conn->prepare($sql);
             $stmt->execute(['userId' => $x]);
             
             // Calculate the total expenses
             $totalExpenses = 0;
             while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                 $totalExpenses += $row['subcategory_total'];
             }
             
             // Calculate and print the percentage of each subcategory
             $stmt->execute(['userId' => $x]);
             while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                 $subcategoryName = $row['Sub-category_name'];
                 $subcategoryTotal = $row['subcategory_total'];
                 $percentage = ($subcategoryTotal / $totalExpenses) * 100;
                 $percentage = number_format($percentage, 2); // Substring to 2 decimal places
                 $hue = mt_rand(0, 360);
                 $saturation = mt_rand(40, 100);
                 $lightness = mt_rand(30, 70);
             
                 // Convert HSL to RGB
                 $rgb = hslToRgb($hue, $saturation, $lightness);
             
                 // Format the RGB values as a hexadecimal color code
                 $color = sprintf('#%02X%02X%02X', $rgb[0], $rgb[1], $rgb[2]);
             
                 // Add the color to the array
                 array_push($colors, $color);

                  
                  
                        ?>
                        <p class="green small" style="color: <?php echo $colors[$control];?>;"><?php echo "$subcategoryName($percentage%)";?></p>
                        <?php $control++; } ?>
                     </div>
                  </div>
            </div>
            <div class="container flex shadow">
               <?php
               $expense = 0;
               $income = 0;
                    $sql = "SELECT * FROM tbl_settings WHERE User_Id = $x";
                    $result = $conn->query($sql);
                    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                     $budget = $row['budget'];
                   } 
                   $sql = "SELECT * FROM tbl_spendings WHERE User_Id = $x";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
if($row['Category_Id'] == 1){
   $expense = $expense+$row['Cost'];
}else{
   $income = $income+$row['Cost'];
}
}
if(isset($budget)){
               ?>
                  <h3 class="expense_label"></i>Expense<span class="right red"><?php echo $expense; ?></span></h3>
                  <h3 class="expense_label">Budget<span class="right blue"><?php echo $budget; ?></span></h3>
                  <hr>
                  <h3 class="expense_label">Balance<span class="right green"><?php echo $budget - $expense;?> </span></h3>
                  <?php } else if (isset($income)){?>
                     <h3 class="expense_label"></i>Expense<span class="right red"><?php echo $expense; ?></span></h3>
                  <h3 class="expense_label">Income<span class="right blue"><?php echo $income; ?></span></h3>
                  <hr>
                  <h3 class="expense_label">Balance<span class="right green"><?php echo $income - $expense;?> </span></h3>
                  <?php }else{?>
                     <h3 class="expense_label"></i>Expense<span class="right red">0</span></h3>
                  <h3 class="expense_label">Budget<span class="right blue">0</span></h3>
                  <hr>
                  <h3 class="expense_label">Balance<span class="right green">0 </span></h3>
                  <?php } ?>
            </div>
         </div>
         <div class="input_spendings">
            <input type="checkbox" name="settings" id="add_button" class="add_button">
            <label for="add_button" class="add_button_label"></label>
            <div class="input_spendings_content expand">
               <div class="spendings_date">
                  <p id="datetime"></p>
                  <label for="custom-datetime">Custom date and time:</label>
                  <input type="datetime-local" pattern="(0[1-9]|1[0-2])/(0[1-9]|1\d|2\d|3[01])/([12]\d{3}), (0[1-9]|1[0-2]):([0-5]\d):([0-5]\d) ([APap][Mm])" name ="date"id="custom-datetime" onchange="setCustomDateTime()">
               </div>
               <div class="spendings">
                  <div class="spendings_category">
                     <div class="input_label"><h1>Category</h1></div>
                     <div class="input_item_name block">
                        <label for="item_name" class="input_sub-label">Item name</label>
                        <input type="text" name="item_name" id="item_name">
                     </div>
                     <div class="input_category block">
                        <label for="category_name"  class="input_sub-label">Category</label>
                        <select name="category_name" id="category_name" onchange="updateSubCategoryOptions()">
                           <option value="" disabled selected>Select Category</option>
                           <option value="Expenses">Expenses</option>
                           <option value="Income">Incomes</option>
                        </select>
                     </div>
                     <div class="sub-category block">
                        <label for="sub-category_name"  class="input_sub-label">Sub-Category</label>
                        <select name="subcategory_name" id="sub-category_name">
                           <option value="" disabled selected>Select Sub-Category</option>

                        </select>
                     </div>
                  </div>
                  <div class="spendings_calculator">
                     <div class="input_label"><h1>Amount</h1></div>
                     <div class="calculator">
                        <input type="text" id="currentNumber" name="amount">
                        <div class="buttons">
                           <button onclick="appendValue('1')">1</button>
                           <button onclick="appendValue('2')">2</button>
                           <button onclick="appendValue('3')">3</button>
                           <button onclick="appendValue('+')">+</button>
                           <button onclick="appendValue('4')">4</button>
                           <button onclick="appendValue('5')">5</button>
                           <button onclick="appendValue('6')">6</button>
                           <button onclick="appendValue('-')">-</button>
                           <button onclick="appendValue('7')">7</button>
                           <button onclick="appendValue('8')">8</button>
                           <button onclick="appendValue('9')">9</button>
                           <button onclick="appendValue('*')">*</button>
                           <button onclick="clearInput()">C</button>
                           <button onclick="appendValue('0')">0</button>
                           <button onclick="appendValue('/')">/</button>
                           <button onclick="calculate()">=</button>
                           <button onclick="deleteLastCharacter()">DEL</button>
                           <input type="button" class="add_button" value="Add" onclick="addItemToTable()">
                        </div>
                        <?php 
                        //
                        $currentDateTime = date('Y-m-d H:i:s');
                        $currentdate = date('Y-m-d H:i:s', strtotime('-6 hours', strtotime($currentDateTime)));
                       // echo $currentdate;
                        ?>
                     </div>
                  </div>
                  <div class="input_spendings_overview">
                     <div class="input_label"><h1>Input Overview</h1></div>
                     <div class="overview">
                        <!--basta yung parang sa recent activity lang din-->
                        <table class="input_overview" id="item_table">
                           <thead>
                           <tr>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                           </tr>
                        </table>
                     </thead>
                     </div>
                     <div class="input_save">
                        <button onclick="saveTextToFile()" class="save">SAVE</button>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="user-table-outercase">
            <ul class="user-table-heading">
              <li>Name</li>
              <li>Category</li>
              <li>Sub-Category</li>
              <li>Amount</li>
              <li>Date</li>
              <li>Operation</li>
            </ul>
            <div class="user-table-innercase">
               <table class="user-table">
               <?php

$sql = "SELECT * FROM tbl_spendings WHERE User_Id = $x";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
$sid = $row['Sub-category_Id'];
$id = $row['Category_Id'];
?>
                  <tr>
                     <td><?php echo $row['Item_name']; ?></td>
                     <td><?php 
                     if($id == 1)echo $cat = "Expenses";
                     else echo $cat ='Incomes';
                     ?></td>
                     <?php 
      if ($id == 1) {
         $sqls = "SELECT * FROM tbl_subcatexpenses WHERE `Sub-category_Id` = $sid";
         $results = $conn->query($sqls);
         while ($rows = $results->fetch(PDO::FETCH_ASSOC)) {
            echo  "<td>".$rows['Sub-category_name']."</td>";
            $subcat = $rows['Sub-category_name'];
         }
      } else if ($id == 2) {
         $sqls = "SELECT * FROM tbl_subcatincomes WHERE `Sub-Category_Id` = $sid";
         $results = $conn->query($sqls);
         while ($rows = $results->fetch(PDO::FETCH_ASSOC)) {
           echo  "<td>".$rows['Sub-category_name']."</td>";
           $subcat = $rows['Sub-category_name'];
         }
      }
      ?>
                     <td><?php echo $row['Cost']; ?></td>
                     <td><?php echo $row['Date']; ?></td>

                     <td>                           
                     <button class="btn btn-primary btn-sm editbutton" id="<?php echo $row['Spending_Id']; ?>,, '<?php echo $row['Item_name']; ?>' '<?php echo $cat; ?>', '<?php echo $subcat; ?>', '<?php echo $row['Cost']; ?>', '<?php echo $row['Date']; ?>'" data-bs-toggle="modal" data-bs-target="#editModal"><i class="fa fa-pen"></i></button>
                        <button class="btn btn-danger btn-sm delbutton" data-bs-toggle="modal" data-bs-target="#delModal" onclick="deletexid(<?php echo $row['Spending_Id']; ?>)"><i class="fa fa-trash"></i></button>
                     </td>
                  </tr>
                  <?php
}
?>

               </table>
            </div>
         </div>

         <!-- <footer id="footer">
            <hr class="bottomline">
            <p>Copyright 2022</p>
         </footer> -->
      </div>
   </main>
</body>
<?php

function hslToRgb($h, $s, $l) {
   $h /= 360;
   $s /= 100;
   $l /= 100;

   $r = $l;
   $g = $l;
   $b = $l;
   $v = ($l <= 0.5) ? ($l * (1.0 + $s)) : ($l + $s - $l * $s);
   if ($v > 0) {
       $m=null;
       $sv=null;
       $sextant=null;
       $fract=null;
       $vsf=null;
       $mid1=null;
       $mid2=null;

       $m = $l + $l - $v;
       $sv = ($v - $m) / $v;
       $h *= 6.0;
       $sextant = floor($h);
       $fract = $h - $sextant;
       $vsf = $v * $sv * $fract;
       $mid1 = $m + $vsf;
       $mid2 = $v - $vsf;

       switch ($sextant) {
           case 0:
               $r = $v;
               $g = $mid1;
               $b = $m;
               break;
           case 1:
               $r = $mid2;
               $g = $v;
               $b = $m;
               break;
           case 2:
               $r = $m;
               $g = $v;
               $b = $mid1;
               break;
           case 3:
               $r = $m;
               $g = $mid2;
               $b = $v;
               break;
           case 4:
               $r = $mid1;
               $g = $m;
               $b = $v;
               break;
           case 5:
               $r = $v;
               $g = $m;
               $b = $mid2;
               break;
       }
   }

   $r = round($r * 255);
   $g = round($g * 255);
   $b = round($b * 255);

   return array($r, $g, $b);
}
?>
</html>
<?php

?>