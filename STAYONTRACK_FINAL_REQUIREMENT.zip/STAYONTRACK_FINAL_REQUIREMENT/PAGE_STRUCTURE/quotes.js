// Define an array of financial quotes
var quotes = [
    "\"A wise person should have money in their head, but not in their heart.\" - Jonathan Swift",
    "\"Beware of little expenses; a small leak will sink a great ship.\" - Benjamin Franklin",
    "\"Do not save what is left after spending; instead, spend what is left after saving.\" - Warren Buffett",
    "\"If you buy things you do not need, soon you will have to sell things you need.\" - Warren Buffett",
    "\"Don't tell me where your priorities are. Show me where you spend your money, and I'll tell you what they are.\" - James W. Frick",
    "\"Money grows on the tree of persistence.\" - Japanese Proverb",
    "\"Every time you borrow money, you're robbing your future self.\" - Nathan W. Morris",
    "\"The only way to permanently change the temperature in the room is to reset the thermostat. In the same way, the only way to change your level of financial success 'permanently' is to reset your financial thermostat.\"- T. Harv Eker",
    "\"Financial freedom is available to those who learn about it and work for it.\" - Robert Kiyosaki",
    "\"It's not how much money you make, but how much money you keep, how hard it works for you, and how many generations you keep it for.\" - Robert Kiyosaki"
  ];
  
  // Function to generate a random quote
  function generateRandomQuote() {
    var randomNumber = Math.floor(Math.random() * quotes.length); // Generate a random index
    var randomQuote = quotes[randomNumber]; // Get a quote using the random index
    document.getElementById("quote").textContent = randomQuote; // Display the quote in the HTML
  }
  
  // Generate a random quote when the page loads
  window.addEventListener("load", generateRandomQuote);
  