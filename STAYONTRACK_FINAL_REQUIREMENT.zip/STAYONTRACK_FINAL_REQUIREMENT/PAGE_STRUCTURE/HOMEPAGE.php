<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOMEPAGE</title>
    <link rel="stylesheet" href="Homepage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link id="theme-link" rel="stylesheet" href="default-theme.css">
    <script src="theme-toggle.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
   <style>
      .chart-container {
         width: 250px; /* Set the desired width */
         height: 250px; /* Set the desired height */
         display: inline-block; /* Display charts side by side */
         margin-right: 20px; /* Add some spacing between the charts */
      }
   </style>
    <link rel="stylesheet" href="assets/bootstrap-5.3.0-alpha3-dist/css/bootstrap.css">
    <script src="assets/bootstrap-5.3.0-alpha3-dist/js/bootstrap.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
    <!-- Jquery -->
    <script src="assets/jquery-3.6.4.js"></script>
    
    <script>
    // Retrieve the stored theme when the page loads
    window.addEventListener('DOMContentLoaded', function() {
      var theme = localStorage.getItem('theme');
      if (theme === 'dark') {
        applyDarkTheme();
      }
      });
      
    </script>
    <?php
    include('config.php');
if(isset($_POST['delUser'])){
   $sql="DELETE FROM tbl_spendings WHERE Spending_Id=:userid";
   $stmt=$conn->prepare($sql);  
   $stmt->execute([':userid'=>$_POST['xid']]);
   echo '<script>alert("1 record deleted")</script>';
 }



 if(isset($_POST['editUser'])){
   $subcat = $_POST['subcat'];
   $cat = $_POST['cat'];
   
   if ($cat == 'Expenses') {
       $cid = 1;
   } else {
       $cid = 2;
   }
   
   $sql = "SELECT * FROM tbl_subcatexpenses WHERE `Sub-category_name` = :subcat";
   $stmt = $conn->prepare($sql);
   $stmt->execute([':subcat' => $subcat]);
   
   while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
       if (isset($row['Sub-category_Id'])) {
           $subid = $row['Sub-category_Id'];
       }
   }
   
   // Additional code or operations here
   
   $sql = "SELECT * FROM tbl_subcatexpenses WHERE `Sub-category_name` = :subcat";
   $stmt = $conn->prepare($sql);
   $stmt->execute([':subcat' => $subcat]);
   
   while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
       if (isset($row['Sub-Category_Id'])) {
           $subid = $row['Sub-Category_Id'];
       }
   }
            

$sql = "UPDATE tbl_spendings SET Item_name = :uname, Category_Id = :pswd, `Sub-category_Id` = :acct, Cost = :upic, Date = :upics WHERE Spending_Id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([
    ':uname' => $_POST['itemname'],
    ':pswd' => $cid,
    ':acct' => $subid,
    ':upic' => $_POST['amount'],
    ':upics' => $_POST['date'],
    ':id' => $_POST['exid']
]);
echo '<script>alert("1 record updated successfully")</script>';
 }
?>
   <script src="quotes.js"></script>
    <script>
      
    function updateDateTime() {
      var now = new Date();
      var dateTimeElement = document.getElementById("datetime");
      dateTimeElement.innerHTML = now.toLocaleString();
    }

    function setCustomDateTime() {
      var customDateTimeElement = document.getElementById("custom-datetime");
      var selectedDateTime = new Date(customDateTimeElement.value);
      if (!isNaN(selectedDateTime.getTime())) {
        var dateTimeElement = document.getElementById("datetime");
        dateTimeElement.innerHTML = selectedDateTime.toLocaleString();
      }
    }

    // Update the date and time every second
    setInterval(updateDateTime, 1000);
  </script>
  <!--CALCULATOR SCRIPT-->
  <script>
      var currentNumber = '';

      function appendValue(value) {
         currentNumber += value;
         document.getElementById('currentNumber').value = currentNumber;
      }

      function calculate() {
         var result = eval(currentNumber);
         document.getElementById('currentNumber').value = result;
         currentNumber = result.toString();
      }

      function clearInput() {
         currentNumber = '';
         document.getElementById('currentNumber').value = '';
      }

      function deleteLastCharacter() {
         currentNumber = currentNumber.slice(0, -1);
         document.getElementById('currentNumber').value = currentNumber;
      }

      // Event listener for keyboard input
      document.addEventListener('keydown', function(event) {
         var key = event.key;
         if (!isNaN(key) || key === '+' || key === '-' || key === '*' || key === '/' || key === '.') {
            appendValue(key);
         } else if (key === 'Enter') {
            calculate();
         } else if (key === 'Backspace') {
            deleteLastCharacter();
         }
      });

      function addItemToTable() {
  var itemInput = document.getElementById("item_name");
  var AmountInput = document.getElementById("currentNumber");
  var categoryDropdown = document.getElementById("category_name");
  var subCategoryDropdown = document.getElementById("sub-category_name");
  var itemTable = document.getElementById("item_table");
  var dateInput = document.getElementById("custom-datetime");

  var item = itemInput.value;
  var category = categoryDropdown.value;
  var subCategory = subCategoryDropdown.value;
  var amount = AmountInput.value;
  var date = dateInput.value;     
      
         
  // Check if the date input field is empty
  if (date === "") {
    var currentDate = new Date();
    var options = {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      hour12: true
    };
    date = currentDate.toLocaleString("en-US", options).replace(/, /, ', ');
  } else {
    var dateObject = new Date(date);
    var options = {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      hour12: true
    };
    date = dateObject.toLocaleString("en-US", options);
  }

  var xhr = new XMLHttpRequest();
  xhr.open('POST', 'saveToFile.php', true);
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  xhr.onreadystatechange = function() {
    if (xhr.readyState === XMLHttpRequest.DONE) {
      if (xhr.status === 200) {
        console.log('Text data saved successfully.');
      } else {
        console.error('Error saving text data:', xhr.status);
      }
    }
  };
  
  var params = 'item=' + encodeURIComponent(item) +
               '&category=' + encodeURIComponent(category) +
               '&subCategory=' + encodeURIComponent(subCategory) +
               '&amount=' + encodeURIComponent(amount) +
               '&date=' + encodeURIComponent(date);
  
  xhr.send(params); 

  if ( category !== "" && subCategory !== "" && amount !== "") {
    var row = itemTable.insertRow(-1);
    var itemCell = row.insertCell(0);
    var categoryCell = row.insertCell(1);
    var subCategoryCell = row.insertCell(2);
    var amountCell = row.insertCell(3);
    var dateCell = row.insertCell(4);

    itemCell.innerHTML = item;
    categoryCell.innerHTML = category;
    subCategoryCell.innerHTML = subCategory;
    amountCell.innerHTML = amount;
    dateCell.innerHTML = date;

    // Clear input fields
    itemInput.value = "";
    categoryDropdown.selectedIndex = 0;
    subCategoryDropdown.selectedIndex = 0;
    dateInput.value = "";
    clearInput();
  } else {
    alert("Please fill in all fields");
  }

 
  
}

function saveTextToFile() {
   var xhr = new XMLHttpRequest();
  xhr.open('GET', 'insert.php', true);
  xhr.onreadystatechange = function() {
    if (xhr.readyState === XMLHttpRequest.DONE) {
      if (xhr.status === 200) {
        console.log('PHP code executed successfully.');
        // Additional code to handle the response from insert.php if needed
      } else {
        console.error('Error executing PHP code:', xhr.status);
      }
    }
  };
  xhr.send();

  var itemTable = document.getElementById("item_table");
itemTable.innerHTML = "";

document.location.reload();
  
      
}



      function updateSubCategoryOptions() {
    var categoryDropdown = document.getElementById("category_name");
    var subCategoryDropdown = document.getElementById("sub-category_name");
    var subCategoryContainer = document.getElementById("sub-category-container");

    if (categoryDropdown.value === "Expenses") {
        <?php 
        include('config.php');
        $sql = "SELECT * FROM tbl_subcatexpenses";
        $result = $conn->query($sql);
        $options = "";

        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $subCategoryName = $row['Sub-category_name'];
            $options .= "<option value=\"$subCategoryName\">$subCategoryName</option>";
        }
        ?>

        subCategoryDropdown.innerHTML = `
            <option value="" disabled selected>Select Sub-Category</option>
            <?php echo $options; ?>
        `;
    } else if (categoryDropdown.value === "Income") {
      <?php 
        include('config.php');
        $sql = "SELECT * FROM tbl_subcatincomes";
        $result = $conn->query($sql);
        $options = "";

        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $subCategoryName = $row['Sub-category_name'];
            $options .= "<option value=\"$subCategoryName\">$subCategoryName</option>";
        }
        ?>

        subCategoryDropdown.innerHTML = `
            <option value="" disabled selected>Select Sub-Category</option>
            <?php echo $options; ?>
        `;
    }

    subCategoryContainer.style.display = "block";
}
   </script>   
</head>
<body>
<script></script>
   <header class="flex">
      <img src="ICON/blue.png" alt="logo" class="logo_blue">
      <button id="theme-toggle-button" onclick="toggleTheme()" class="default">
         <i id="theme-toggle-icon" class="fas fa-sun"></i>
      </button>
   </header>
   <main>
      <div class="flex shadow outside_expense">
         <h3 class="expense_label">Expense<span class="right red">3,400</span></h3>
         <h3 class="expense_label">Budget<span class="right blue">5,000</span></h3>
         <hr>
      </div>
      <div>
         <input type="checkbox" name="sidebar" id="sidebar">
         <label for="sidebar"><img src="ICON/icons8-menu-50.png" alt="menu" class="menu_icon"></label>
         <div class="navigation">
            <div class="profile">
               
               <?php
               // fix it, it does not select the current person who login
               include('config.php');
               $sql = "SELECT * FROM tbl_tracking";
               $result=$conn->query($sql);
               while($row=$result->fetch(PDO::FETCH_ASSOC)){
               $x = $row['User_Id'];
               }
               $sql = "SELECT * FROM tbl_accounts WHERE ID = $x";
               $result=$conn->query($sql);
               $row = $result->fetch(PDO::FETCH_ASSOC);
               ?>
               <?php  echo "<img alt = 'profile'style='height:100px;width:100px;border-radius:100px'; src='images/".$row['user_pic']."' >"; ?>
               <p><?php echo $row['username'] ?></p>
               <p>*****</p>
            </div>


            <div class="nav">
                  <nav>
                     <div class="line"></div>
                     <a href="HOMEPAGE.php"><img class="nav_icon" src="ICON/icons8-home-24 (1).png" alt="home_icon"><span>HOME</span></a>
                     <a href="TRANSACTION.php"><img class="nav_icon" src="ICON/icons8-budgeting-48.png" alt="transac_icon"><span>TRANSACTION</span></a>
                     <a href="CATEGORY.php"><img class="nav_icon" src="ICON/icons8-filing-cabinet-50.png" alt="category_icon"><span>CATEGORY</span></a>
                     <a href="TIPS.php"><img class="nav_icon" src="ICON/icons8-bulb-32.png" alt="tips_icon   "><span>TIPS</span></a>
                     <br>
                     <br>
                     <a href="SETTINGS.php"><img class="nav_icon" src="ICON/icons8-setting-24.png" alt="settings_icon"><span>SETTINGS</span></a>
                     <a href="HELP.php"><img class="nav_icon" src="ICON/icons8-about-30.png" alt="help_icon"><span>HELP</span></a>
                     <!-- <div class="line"></div> -->
                     <a href="SIGN_UP_PAGE.php"><img class="nav_icon" src="ICON/icons8-logout-30.png" alt="logout_icon"><span>LOG OUT</span></a>
                  </nav>
            </div>  
         </div>   
      </div>
      <div class="main-content"> 
         <div class="quote-casing">
            <h1 id="quote"></h1>
         </div>
            <hr>
         <div class="housing flex">
            <div class="report flex shadow">
               <?php
include('config.php');
$sql = "SELECT * FROM tbl_tracking";
$result=$conn->query($sql);
while($row=$result->fetch(PDO::FETCH_ASSOC)){
$x = $row['User_Id'];
}
$sql = "SELECT * FROM tbl_accounts WHERE ID = $x";
$result=$conn->query($sql);
$row = $result->fetch(PDO::FETCH_ASSOC);

$sql = "SELECT * FROM tbl_spendings WHERE User_Id = $x";
$result = $conn->query($sql);
$enddate; 
$startdate;
$last;
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
$enddate = $row['Date'];
$last = $row['Spending_Id'];
}
$sql = "SELECT * FROM tbl_spendings WHERE User_Id = $x";
   $result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
if(!isset($startdate)){
$startdate = $row['Date'];

}
}
   $sql = "SELECT * FROM tbl_spendings WHERE User_Id = $x";
   $result = $conn->query($sql);
   $sum =0;
   $onetime = false;
   @$temp = new DateTime($startdate);
    $temps = clone $temp; 
    $temps2 = clone $temp;
   while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
// Add one week to the cloned object for the next iteration
if($onetime == false){
  $temps->add(new DateInterval('P1W'));
  $onetime = true;
}

  $a = $temps->format('m/d/Y');  

   if($row['Date']<$a && $row['Spending_Id'] != $last){
    if($row['Category_Id'] == 1){
      $sum+=$row['Cost'];
   }
   } else if($row['Spending_Id'] == $last){  
    if($row['Category_Id'] == 1){
      $sum+=$row['Cost'];
   }
    $dateInWords2 = $temps2->format('F j, Y');
    $dateInWords = $temps->format('F j, Y');
    $MONTH = $temps2->format('F');
    }} 
               ?>
                  <h3 class="summary flex">Recent Summary<span> <?php 
                  if(isset($MONTH)){
                  echo $MONTH;
                  }else{
                     echo 'MONTH';
                  }

                  ?>
                  
               </span></h3>
                  <div class="chart_housing flex">
                  <div class="chart-container">
                        <canvas id="donutChart1"></canvas>
                     </div>

                     <?php
$arr1 = [];
$arr2 = [];
$count1 = [];
$count2 = [];
$expenses = 0;
$incomes = 0;

$sql = "SELECT * FROM tbl_subcatexpenses";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
   $arr1[$row['Sub-category_Id']] = $row['Sub-category_name'];
}
$sql = "SELECT * FROM tbl_subcatincomes";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
   $arr2[$row['Sub-Category_Id']] = $row['Sub-category_name'];
}

$sql = "SELECT * FROM tbl_spendings";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
   if ($row['Category_Id'] == 1) {
      $expenses++;
      if (isset($arr1[$row['Sub-category_Id']])) {
         if (isset($count1[$row['Sub-category_Id']])) {
            $count1[$row['Sub-category_Id']]++;
         } else {
            $count1[$row['Sub-category_Id']] = 1;
         }
      }
   } else {
      $incomes++;
     if (isset($arr2[$row['Sub-category_Id']])) {
         if (isset($count2[$row['Sub-category_Id']])) {
            $count2[$row['Sub-category_Id']]++;
         } else {
            $count2[$row['Sub-category_Id']] = 1;
         }
      }
   }
}

$totalExpenses = array_sum($count1);
$totalIncomes = array_sum($count2);


foreach ($count1 as $subCategoryId => $count) {
   $percentage = ($count / $totalExpenses) * 100;
   $subCategoryName = $arr1[$subCategoryId];

}


foreach ($count2 as $subCategoryId => $count) {
   $percentage = ($count / $totalIncomes) * 100;
   $subCategoryName = $arr2[$subCategoryId];

}
// Find the least used category
$leastUsedCategory = null;
$leastUsedCount = PHP_INT_MAX;

foreach ($count1 as $subCategoryId => $count) {
   if ($count < $leastUsedCount) {
      $leastUsedCategory = $arr1[$subCategoryId];
      $leastUsedCount = $count;
   }
}

foreach ($count2 as $subCategoryId => $count) {
   if ($count < $leastUsedCount) {
      $leastUsedCategory = $arr2[$subCategoryId];
      $leastUsedCount = $count;
   }
}

// Find the most used category
$mostUsedCategory = null;
$mostUsedCount = 0;

foreach ($count1 as $subCategoryId => $count) {
   if ($count > $mostUsedCount) {
      $mostUsedCategory = $arr1[$subCategoryId];
      $mostUsedCount = $count;
   }
}

foreach ($count2 as $subCategoryId => $count) {
   if ($count > $mostUsedCount) {
      $mostUsedCategory = $arr2[$subCategoryId];
      $mostUsedCount = $count;
   }
}

// Print the least used and most used categories


$total = $expenses + $incomes;

$percentage1 = ($expenses / $total) * 100;
$percentage2 = ($incomes/ $total) * 100;

$colors = generateReadableColors(10); // Generate an array of 10 readable colors

// Function to generate readable colors
function generateReadableColors($count) {
    $colors = [];
    $lightnessThreshold = 0.6; // Adjust this value for desired darkness threshold

    for ($i = 0; $i < $count; $i++) {
        $color = generateRandomColor();
        $lightness = calculateColorLightness($color);

        while ($lightness > $lightnessThreshold) {
            $color = generateRandomColor();
            $lightness = calculateColorLightness($color);
        }

        $colors[] = $color;
    }

    return $colors;
}

// Function to generate a random color
function generateRandomColor() {
    $letters = '0123456789ABCDEF';
    $color = '#';

    // Generate a random six-digit hexadecimal color code
    for ($i = 0; $i < 6; $i++) {
        $color .= $letters[rand(0, 15)];
    }

    return $color;
}

// Function to calculate the lightness of a color
function calculateColorLightness($color) {
    $color = str_replace('#', '', $color);
    $r = hexdec(substr($color, 0, 2));
    $g = hexdec(substr($color, 2, 2));
    $b = hexdec(substr($color, 4, 2));
    $lightness = (max($r, $g, $b) + min($r, $g, $b)) / (2 * 255);

    return $lightness;
}
$sql = "SELECT * FROM tbl_tracking";
    $result=$conn->query($sql);
    while($row=$result->fetch(PDO::FETCH_ASSOC)){
    $x = $row['User_Id'];
    }
    $userSubcategoryAmounts = []; // Array to store subcategory amounts for the user

    foreach ($count1 as $subCategoryId => $count) {
       $percentage = ($count / $totalExpenses) * 100;
       $subCategoryName = $arr1[$subCategoryId];
       $userSubcategoryAmounts[$subCategoryName] = 0; // Initialize amount as 0
    }
    
    foreach ($count2 as $subCategoryId => $count) {
       $percentage = ($count / $totalIncomes) * 100;
       $subCategoryName = $arr2[$subCategoryId];
       $userSubcategoryAmounts[$subCategoryName] = 0; // Initialize amount as 0
    }
    
    $userId = $x; // Replace $x with the actual User_Id
    
    $sql = "SELECT * FROM tbl_spendings WHERE User_Id = :userId";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':userId', $userId);
    $stmt->execute();
    

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
       $subCategoryId = $row['Sub-category_Id'];
       $category = $row['Category_Id'];
       $amount = $row['Cost'];
    
       if ($category == 1 && isset($arr1[$subCategoryId])) {
          $subCategoryName = $arr1[$subCategoryId];
          $userSubcategoryAmounts[$subCategoryName] += $amount;
       } elseif ($category == 2 && isset($arr2[$subCategoryId])) {
          $subCategoryName = $arr2[$subCategoryId];
          $userSubcategoryAmounts[$subCategoryName] += $amount;
       }
    }
    

 
?>

                    
                    
                     <div class="chart_content">
                        <?php
                        $colorss = [];
                        $control = 0;
                     $sql = "SELECT subcat.`Sub-category_name`, SUM(spending.cost) AS subcategory_total
                     FROM tbl_spendings spending
                     INNER JOIN tbl_subcatexpenses subcat ON spending.`Sub-category_Id` = subcat.`Sub-category_Id`
                     WHERE spending.`Category_Id` = 1 AND spending.`User_Id` = :userId
                     GROUP BY spending.`Sub-category_Id`";
             
             $stmt = $conn->prepare($sql);
             $stmt->execute(['userId' => $x]);
             
             // Calculate the total expenses
             $totalExpenses = 0;
             while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                 $totalExpenses += $row['subcategory_total'];
             }
             
             // Calculate and print the percentage of each subcategory
             $stmt->execute(['userId' => $x]);
             while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                 $subcategoryName = $row['Sub-category_name'];
                 $subcategoryTotal = $row['subcategory_total'];
                 $percentage = ($subcategoryTotal / $totalExpenses) * 100;
                 $percentage = number_format($percentage, 2); // Substring to 2 decimal places
                 $hue = mt_rand(0, 360);
                 $saturation = mt_rand(40, 100);
                 $lightness = mt_rand(30, 70);
             
                 // Convert HSL to RGB
                 $rgb = hslToRgb($hue, $saturation, $lightness);
             
                 // Format the RGB values as a hexadecimal color code
                 $color = sprintf('#%02X%02X%02X', $rgb[0], $rgb[1], $rgb[2]);
             
                 // Add the color to the array
                 array_push($colors, $color);
                ?>
                        <style>
                                    .chart_housing{
                  border: 1px solid #7f7d81;
                  border-radius: 10px;
                  padding: 5px 20px;
                  box-sizing: border-box;
                  width: 100%;
                  height: 80%;
                  margin-top: -15px;
                  gap: 20px;
                  justify-content: left;
                  overflow: hidden;
               }

               .chart{
                  width: 27vh;
                  height: 27vh;
                  border-radius: 50%;
                  background: repeating-conic-gradient(
                     from 0deg, 
                     <?php if(count($colors)==1){?>
                        <?php echo $colors[0];?> 0deg calc(3.6deg * 100)
                        <?php } ?>
                  );
                  justify-content: center;
               }
               .inchart{
                  width: 18vh;    
                  height: 18vh;
                  border-radius: 50%;
                  background-color: #eeeeeefe;  
               }
               .small{
                  font-size: 12px;
               }<?php $control++; } ?>
                  </style>
                        
                        
                     </div>
                  </div>
            </div>
            <div class="container flex shadow">
               <?php
               $expense = 0;
               $income = 0;
                    $sql = "SELECT * FROM tbl_settings WHERE User_Id = $x";
                    $result = $conn->query($sql);
                    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                     $budget = $row['budget'];
                   } 
                   $sql = "SELECT * FROM tbl_spendings WHERE User_Id = $x";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
if($row['Category_Id'] == 1){
   $expense = $expense+$row['Cost'];
}else{
   $income = $income+$row['Cost'];
}
}
if(isset($budget)){
               ?>
                  <h3 class="expense_label"></i>Expense<span class="right red"><?php echo $expense; ?></span></h3>
                  <h3 class="expense_label">Budget<span class="right blue"><?php echo $budget; ?></span></h3>
                  <hr>
                  <h3 class="expense_label">Balance<span class="right green"><?php echo $budget - $expense;?> </span></h3>
                  <?php } else if (isset($income)){?>
                     <h3 class="expense_label"></i>Expense<span class="right red"><?php echo $expense; ?></span></h3>
                  <h3 class="expense_label">Income<span class="right blue"><?php echo $income; ?></span></h3>
                  <hr>
                  <h3 class="expense_label">Balance<span class="right green"><?php echo $income - $expense;?> </span></h3>
                  <?php }else{?>
                     <h3 class="expense_label"></i>Expense<span class="right red">0</span></h3>
                  <h3 class="expense_label">Budget<span class="right blue">0</span></h3>
                  <hr>
                  <h3 class="expense_label">Balance<span class="right green">0 </span></h3>
                  <?php } ?>
            </div>
         </div>
         <div class="input_spendings">
            <input type="checkbox" name="settings" id="add_button" class="add_button">
            <label for="add_button" class="add_button_label"></label>
            <div class="input_spendings_content expand">
               <div class="spendings_date">
                  <p id="datetime"></p>
                  <label for="custom-datetime">Custom date and time:</label>
                  <input type="datetime-local" pattern="(0[1-9]|1[0-2])/(0[1-9]|1\d|2\d|3[01])/([12]\d{3}), (0[1-9]|1[0-2]):([0-5]\d):([0-5]\d) ([APap][Mm])" name ="date"id="custom-datetime" onchange="setCustomDateTime()">
               </div>
               <div class="spendings">
                  <div class="spendings_category">
                     <div class="input_label"><h1>Category</h1></div>
                     <div class="input_item_name block">
                        <label for="item_name" class="input_sub-label">Item name</label>
                        <input type="text" name="item_name" id="item_name">
                     </div>
                     <div class="input_category block">
                        <label for="category_name"  class="input_sub-label">Category</label>
                        <select name="category_name" id="category_name" onchange="updateSubCategoryOptions()">
                           <option value="" disabled selected>Select Category</option>
                           <option value="Expenses">Expenses</option>
                           <option value="Income">Incomes</option>
                        </select>
                     </div>
                     <div class="sub-category block">
                        <label for="sub-category_name"  class="input_sub-label">Sub-Category</label>
                        <select name="subcategory_name" id="sub-category_name">
                           <option value="" disabled selected>Select Sub-Category</option>

                        </select>
                     </div>
                  </div>
                  <div class="spendings_calculator">
                     <div class="input_label"><h1>Amount</h1></div>
                     <div class="calculator">
                        <input type="text" id="currentNumber" name="amount">
                        <div class="buttons">
                           <button onclick="appendValue('1')">1</button>
                           <button onclick="appendValue('2')">2</button>
                           <button onclick="appendValue('3')">3</button>
                           <button onclick="appendValue('+')">+</button>
                           <button onclick="appendValue('4')">4</button>
                           <button onclick="appendValue('5')">5</button>
                           <button onclick="appendValue('6')">6</button>
                           <button onclick="appendValue('-')">-</button>
                           <button onclick="appendValue('7')">7</button>
                           <button onclick="appendValue('8')">8</button>
                           <button onclick="appendValue('9')">9</button>
                           <button onclick="appendValue('*')">*</button>
                           <button onclick="clearInput()">C</button>
                           <button onclick="appendValue('0')">0</button>
                           <button onclick="appendValue('/')">/</button>
                           <button onclick="calculate()">=</button>
                           <button onclick="deleteLastCharacter()">DEL</button>
                           <input type="button" class="add_button" value="Add" onclick="addItemToTable()">
                        </div>
                        <?php 
                        //
                        $currentDateTime = date('Y-m-d H:i:s');
                        $currentdate = date('Y-m-d H:i:s', strtotime('-6 hours', strtotime($currentDateTime)));
                       // echo $currentdate;
                        ?>
                     </div>
                  </div>
                  <div class="input_spendings_overview">
                     <div class="input_label"><h1>Input Overview</h1></div>
                     <div class="overview">
                     <div class="input_heading">
                              <ul>
                                 <li>Name</li>
                                 <li>Category</li>
                                 <li>Sub-Cat</li>
                                 <li>Amount</li>   
                                 <li>Date</li>
                              </ul>
                        </div>

                        <!--basta yung parang sa recent activity lang din-->
                        <table class="input_overview" id="item_table">
                           <thead>
       
                        </table>
                     </thead>
                     </div>
                     <div class="input_save">
                        <button onclick="saveTextToFile()" class="save">SAVE</button>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <h3 class="caption">Recent Expenses</h3>
         <div class="user-table-outercase">
            <ul class="user-table-heading">
              <li>Name</li>
              <li>Category</li>
              <li>Sub-Category</li>
              <li>Amount</li>
              <li>Date</li>
              <li>Operation</li>
            </ul>
            <div class="user-table-innercase">
               <table class="user-table">
               <?php

$sql = "SELECT * FROM tbl_spendings WHERE User_Id = $x";
$result = $conn->query($sql);
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
$sid = $row['Sub-category_Id'];
$id = $row['Category_Id'];
?>
                  <tr>
                     <td><?php echo $row['Item_name']; ?></td>
                     <td><?php 
                     if($id == 1)echo $cat = "Expenses";
                     else echo $cat ='Incomes';
                     ?></td>
                     <?php 
      if ($id == 1) {
         $sqls = "SELECT * FROM tbl_subcatexpenses WHERE `Sub-category_Id` = $sid";
         $results = $conn->query($sqls);
         while ($rows = $results->fetch(PDO::FETCH_ASSOC)) {
            echo  "<td>".$rows['Sub-category_name']."</td>";
            $subcat = $rows['Sub-category_name'];
         }
      } else if ($id == 2) {
         $sqls = "SELECT * FROM tbl_subcatincomes WHERE `Sub-Category_Id` = $sid";
         $results = $conn->query($sqls);
         while ($rows = $results->fetch(PDO::FETCH_ASSOC)) {
           echo  "<td>".$rows['Sub-category_name']."</td>";
           $subcat = $rows['Sub-category_name'];
         }
      }
      ?>
                     <td><?php echo $row['Cost']; ?></td>
                     <td><?php echo $row['Date']; ?></td>

                     <td>                           
                     <button class="btn btn-primary btn-sm editbutton"   onclick="editxid(<?php echo $row['Spending_Id']; ?>, '<?php echo $row['Item_name']; ?>','<?php echo $cat; ?>', '<?php echo $subcat; ?>', '<?php echo $row['Cost']; ?>', '<?php echo $row['Date']; ?>')" data-bs-toggle="modal" data-bs-target="#editModal"><i class="fa fa-pen"></i></button>
                        <button class="btn btn-danger btn-sm delbutton" data-bs-toggle="modal" data-bs-target="#delModal" onclick="deletexid(<?php echo $row['Spending_Id']; ?>)"><i class="fa fa-trash"></i></button>
                     </td>
                  </tr>
                  <?php
}
?>

               </table>
            </div>
         </div>

         <footer id="footer">
            <hr class="bottomline">
            <p>Copyright 2022</p>
         </footer>
      </div>
   </main>
   <!-------------------------- delete Modal -------------------------->
   <div class="modal fade" id="delModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Delete Item</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                  <!-- <span aria-hidden="true">&times;</span> -->
                  </button>
              </div>
              <div class="modal-body">
                  <p>Are you sure you want to delete?</p>
              </div>
              <div class="modal-footer">
                  <form action="" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="xid" id="delid">
                    <button type="submit" class="btn btn-primary" name="delUser">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                  </form>
              </div>
            </div>
        </div>
    </div>

         <!-------------------------- edit Modal -------------------------->
         <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="" method="POST" enctype="multipart/form-data">
                  <!-- item -->
				<div class="mb-3 mt-3">
					<input type="text" class="form-control" id="itemname" placeholder="Item name" name="itemname" required value="">
				</div>
            <!-- caategory -->
            <label for="acct" class="form-label">Category:</label>
				<select class="form-select" id="cat" name="cat"  required >
					<option value="" readonly>-----Select-----</option>
					<option value="Expenses">Expenses</option>
					<option value="Incomes">Incomes</option>
				</select>
            <!-- sub cat -->
            <label for="acct" class="form-label">Sub-Category: </label>
				<select class="form-select" id="subcat" name="subcat"  required >
					<option value="" readonly>-----Select-----</option>
				</select>
            <script>
    // Get the category and subcategory dropdowns
    var categoryDropdown = document.getElementById('cat');
    var subcategoryDropdown = document.getElementById('subcat');

    // Define the available subcategories for each category
    var subcategories = {
        Expenses: ['Food', 'Transportation', 'Bills', 'Education', 'Social', 'Insurance', 'Cosmetics', 'Health', 'Shopping'],
        Incomes: ['Salary', 'Freelance', 'Business Income', 'Investment Income', 'Commission Income', 'Retirement Income', 'Royalties', 'Part-Time Job Income', 'Family Support']
    };

    // Function to update the subcategory dropdown options based on the selected category
    function updateSubcategories() {
        // Get the selected category
        var selectedCategory = categoryDropdown.value;

        // Clear existing options
        subcategoryDropdown.innerHTML = '';

        // Add the default option
        var defaultOption = document.createElement('option');
        defaultOption.value = '';
        defaultOption.text = '-----Select-----';
        defaultOption.disabled = true;
        defaultOption.selected = true;
        subcategoryDropdown.appendChild(defaultOption);

        // Add the subcategory options based on the selected category
        subcategories[selectedCategory].forEach(function (subcategory) {
            var option = document.createElement('option');
            option.value = subcategory;
            option.text = subcategory;
            
            // Check if the option matches the values passed to the editxid function
            if (selectedCategory === cat && subcategory === subcat) {
                option.selected = true; // Set the option as selected
            }
            
            subcategoryDropdown.appendChild(option);
        });
    }

    // Event listener to trigger the updateSubcategories function when the category is changed
    categoryDropdown.addEventListener('change', updateSubcategories);

    // Initial update of subcategories based on the default selected category
    updateSubcategories();

    // Function to handle the button click and update the dropdown values

</script>



            <br>
            <!-- amount    -->
				<div class="mb-3">
                        <input type="text" class="form-control" id="amount" placeholder="Enter Amount" name="amount" required value="">
                    </div>
                    <div class="mb-3">
				<!-- date -->
            <div class="mb-3">
            <input type="text" class="form-control" id="date" placeholder="Enter Date (mm/dd/yyyy)" name="date"  value="">

                    </div>
                    <div class="mb-3">
                    <script>
    // Get the date input field
    var dateInput = document.getElementById('date');

    // Function to format the date as "month/day/year"
    function formatDate(date) {
        var month = String(date.getMonth() + 1).padStart(2, '0');
        var day = String(date.getDate()).padStart(2, '0');
        var year = date.getFullYear();
        return month + '/' + day + '/' + year;
    }

    // Get the current date
    var currentDate = new Date();

    // Format the date
    var formattedDate = formatDate(currentDate);

    // Set the formatted date as the value of the date input field
    dateInput.value = formattedDate;
</script>
				</div>
						
                    <div class="modal-footer">
						<form action="" method="POST" enctype="multipart/form-data">
							<input type="hidden" name="exid" id="edid" value="1">
							<button type="submit" class="btn btn-primary" name="editUser">Save</button>
							<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
						</form>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
<script>
   //code to get user_id to delete
   function deletexid(x){ 
    document.getElementById('delid').value=x;
  }

  function editxid(id,name,cat,subcat,amount,date){ 
    document.getElementById('edid').value = id;
    document.getElementById('itemname').value = name;
    document.getElementById('cat').value = cat;
    document.getElementById('subcat').value = subcat;
    document.getElementById('amount').value = amount;
    document.getElementById('date').value = date;
    updateSubcategories();
}

</script>   
<?php

function hslToRgb($h, $s, $l) {
   $h /= 360;
   $s /= 100;
   $l /= 100;

   $r = $l;
   $g = $l;
   $b = $l;
   $v = ($l <= 0.5) ? ($l * (1.0 + $s)) : ($l + $s - $l * $s);
   if ($v > 0) {
       $m=null;
       $sv=null;
       $sextant=null;
       $fract=null;
       $vsf=null;
       $mid1=null;
       $mid2=null;

       $m = $l + $l - $v;
       $sv = ($v - $m) / $v;
       $h *= 6.0;
       $sextant = floor($h);
       $fract = $h - $sextant;
       $vsf = $v * $sv * $fract;
       $mid1 = $m + $vsf;
       $mid2 = $v - $vsf;

       switch ($sextant) {
           case 0:
               $r = $v;
               $g = $mid1;
               $b = $m;
               break;
           case 1:
               $r = $mid2;
               $g = $v;
               $b = $m;
               break;
           case 2:
               $r = $m;
               $g = $v;
               $b = $mid1;
               break;
           case 3:
               $r = $m;
               $g = $mid2;
               $b = $v;
               break;
           case 4:
               $r = $mid1;
               $g = $m;
               $b = $v;
               break;
           case 5:
               $r = $v;
               $g = $m;
               $b = $mid2;
               break;
       }
   }

   $r = round($r * 255);
   $g = round($g * 255);
   $b = round($b * 255);

   return array($r, $g, $b);
}
?>



</html>
<?php

?>
 <script>
                        // Function to create a donut chart
                        function createDonutChart(labels, values, containerId) {
                           // Get the canvas element
                           const canvas = document.getElementById(containerId);

                           // Set the chart data and options
                           const chartData = {
                           labels: labels,
                           datasets: [{
                              data: values,
                              backgroundColor: [<?php
                         for($x=0;$x<count($colors);$x++){
                           echo "'".$colors[$x]."'".",";
                         }
                        
                        ?>],
                              hoverBackgroundColor: [<?php
                         for($x=0;$x<count($colors);$x++){
                           echo "'".$colors[$x]."'".",";
                         }
                        
                        ?>]
                           }]
                           };

                           const chartOptions = {
                           responsive: true,
                           cutoutPercentage: 70,
                           legend: {
                              display: true,
                              position: 'right', // Set the legend position to 'right'
                              labels: {
                                 fontColor: 'black',
                                 fontSize: 14
                              }
                           }
                           };

                           // Create the donut chart
                           new Chart(canvas, {
                           type: 'doughnut',
                           data: chartData,
                           options: chartOptions
                           });
                        }

                        // Example values for the first chart
                        const labels1 = [<?php
                         foreach ($userSubcategoryAmounts as $subCategoryName => $amount) {
                           if($amount != 0){
                           echo "'".$subCategoryName."'".",";
                        }
                        }
                        ?>];
                        const values1 = [<?php
                         foreach ($userSubcategoryAmounts as $subCategoryName => $amount) {
                           if($amount != 0){
                           echo $amount.",";
                        }
                        }
                        ?>];

                        // Create the first donut chart
                        createDonutChart(labels1, values1, 'donutChart1');
                        
                     </script>