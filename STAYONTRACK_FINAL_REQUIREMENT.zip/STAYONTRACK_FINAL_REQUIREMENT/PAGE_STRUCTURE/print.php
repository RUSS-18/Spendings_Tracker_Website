<?php
// File path of the text file
$filePath = 'C:\xampp\htdocs\stayontrack\STAYONTRACK_FINAL_REQUIREMENT\PAGE_STRUCTURE\henlo.txt';

// Check if the file exists
if (file_exists($filePath)) {
  // Read the contents of the file
  $contents = file_get_contents($filePath);

  // Output the contents
  $fileLines = file($filePath, FILE_IGNORE_NEW_LINES);

// Echo each line of the file
foreach ($fileLines as $line) {
    echo $line . "<br>";
}
} else {
  echo "File not found.";
}

?>